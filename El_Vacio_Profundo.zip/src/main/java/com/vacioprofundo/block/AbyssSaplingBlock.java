package com.vacioprofundo.block;

import com.mojang.serialization.MapCodec;
import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.worldgen.feature.GlowTreeFeature;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Brote Abisal: grows into an Abyssal (glow) Tree. Can only be planted on stone, deepslate or deep stone
 * (tag vacio_profundo:abyss_sapling_soil). Grows through random ticks when there is room.
 */
public class AbyssSaplingBlock extends Block {
    public static final MapCodec<AbyssSaplingBlock> CODEC = simpleCodec(AbyssSaplingBlock::new);
    private static final VoxelShape SHAPE = Block.box(3, 0, 3, 13, 13, 13);
    public static final TagKey<Block> SOIL = TagKey.create(Registries.BLOCK, VacioProfundo.id("abyss_sapling_soil"));

    public AbyssSaplingBlock(Properties properties) { super(properties); }
    @Override protected MapCodec<? extends Block> codec() { return CODEC; }
    @Override protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return SHAPE; }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).is(SOIL);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!canSurvive(state, level, pos)) { level.destroyBlock(pos, true); return; }
        if (random.nextInt(6) != 0) return;
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        if (!GlowTreeFeature.grow(level, pos, random)) level.setBlock(pos, state, 3);   // no room: stays a sprout
    }
}

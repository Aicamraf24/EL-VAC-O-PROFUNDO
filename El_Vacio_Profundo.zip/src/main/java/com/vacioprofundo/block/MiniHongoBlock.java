package com.vacioprofundo.block;

import com.mojang.serialization.MapCodec;
import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.registry.ModBlocks;
import com.vacioprofundo.worldgen.feature.GiantMushroomFeature;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Mini Hongo: dropped by mushroom caps. Planted on soil it grows a giant mushroom (stem = Tronco de Hongo) of its own colour. */
public class MiniHongoBlock extends Block {
    public static final MapCodec<MiniHongoBlock> CODEC = simpleCodec(MiniHongoBlock::new);
    public static final TagKey<Block> SOIL = TagKey.create(Registries.BLOCK, VacioProfundo.id("mini_hongo_soil"));
    private static final VoxelShape SHAPE = Block.box(4, 0, 4, 12, 9, 12);

    public MiniHongoBlock(Properties properties) { super(properties); }
    @Override protected MapCodec<? extends Block> codec() { return CODEC; }
    @Override protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return SHAPE; }
    @Override protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) { return level.getBlockState(pos.below()).is(SOIL); }

    private Block cap() {
        String path = BuiltInRegistries.BLOCK.getKey(this).getPath();
        if (path.endsWith("violeta")) return ModBlocks.SOMBRERO_HONGO_VIOLETA;
        if (path.endsWith("ambar")) return ModBlocks.SOMBRERO_HONGO_AMBAR;
        return ModBlocks.SOMBRERO_HONGO_CIAN;
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!canSurvive(state, level, pos)) { level.destroyBlock(pos, true); return; }
        if (random.nextInt(5) != 0) return;
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        if (!GiantMushroomFeature.grow(level, pos, random, cap())) level.setBlock(pos, state, 3);   // no room: stays small
    }
}

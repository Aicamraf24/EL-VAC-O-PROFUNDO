package com.vacioprofundo.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;

/** Interior of the portal. Teleport logic runs in PortalHandler (server tick), not here. */
public class VacioPortalBlock extends Block {
    public static final MapCodec<VacioPortalBlock> CODEC = simpleCodec(VacioPortalBlock::new);
    public VacioPortalBlock(Properties properties) { super(properties); }
    @Override protected MapCodec<? extends Block> codec() { return CODEC; }
}

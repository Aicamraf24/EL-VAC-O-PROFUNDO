package com.vacioprofundo.worldgen;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.worldgen.feature.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public final class ModFeatures {
    private ModFeatures() {}
    static <F extends Feature<NoneFeatureConfiguration>> F reg(String id, F f) { return Registry.register(BuiltInRegistries.FEATURE, VacioProfundo.id(id), f); }
    public static void init() {
        reg("giant_mushroom", new GiantMushroomFeature());
        reg("glow_tree", new GlowTreeFeature());
        reg("crystal_spire", new CrystalSpireFeature());
        reg("stalactite", new StalactiteFeature(true));
        reg("stalagmite", new StalactiteFeature(false));
        reg("abyss_root", new AbyssRootFeature());
    }
}

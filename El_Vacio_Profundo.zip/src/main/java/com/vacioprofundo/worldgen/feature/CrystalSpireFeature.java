package com.vacioprofundo.worldgen.feature;

import com.vacioprofundo.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Tapering, slightly leaning giant crystal spire (8-34 blocks) with satellite crystals. */
public class CrystalSpireFeature extends Feature<NoneFeatureConfiguration> {
    public CrystalSpireFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lvl = ctx.level(); BlockPos o = ctx.origin(); RandomSource r = ctx.random();
        if (!FeatureUtil.solidBelow(lvl, o)) return false;
        Block[] pal = {ModBlocks.CRISTAL_LUMINOSO_CIAN, ModBlocks.CRISTAL_LUMINOSO_VIOLETA, ModBlocks.CRISTAL_LUMINOSO_AMBAR, ModBlocks.CRISTAL_OSCURO_VIOLETA};
        Block main = pal[r.nextInt(3)], dark = ModBlocks.CRISTAL_OSCURO_VIOLETA;
        int h = 8 + r.nextInt(27); double lx = (r.nextDouble() - .5) * 0.5, lz = (r.nextDouble() - .5) * 0.5; int base = 2 + h / 10;
        for (int y = 0; y < h; y++) {
            double t = 1.0 - y / (double) h; int rad = Math.max(0, (int) Math.round(base * t));
            int cx = (int) Math.round(lx * y), cz = (int) Math.round(lz * y);
            for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++)
                if (dx * dx + dz * dz <= rad * rad + 1) FeatureUtil.put(lvl, o.offset(cx + dx, y, cz + dz), r.nextInt(6) == 0 ? dark : main);
        }
        for (int i = 0; i < 3 + r.nextInt(4); i++) {
            int sx = r.nextInt(9) - 4, sz = r.nextInt(9) - 4, sh = 2 + r.nextInt(5);
            for (int y = 0; y < sh; y++) FeatureUtil.put(lvl, o.offset(sx, y, sz), y == sh - 1 ? main : dark);
        }
        return true;
    }
}

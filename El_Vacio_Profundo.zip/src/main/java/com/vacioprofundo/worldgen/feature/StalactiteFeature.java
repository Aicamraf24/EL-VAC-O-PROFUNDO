package com.vacioprofundo.worldgen.feature;

import com.vacioprofundo.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Cone of deep stone growing from the ceiling (down) or the floor (up). */
public class StalactiteFeature extends Feature<NoneFeatureConfiguration> {
    private final boolean hanging;
    public StalactiteFeature(boolean hanging) { super(NoneFeatureConfiguration.CODEC); this.hanging = hanging; }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lvl = ctx.level(); BlockPos o = ctx.origin(); RandomSource r = ctx.random();
        if (hanging ? lvl.getBlockState(o.above()).isAir() : !FeatureUtil.solidBelow(lvl, o)) return false;
        int h = 4 + r.nextInt(hanging ? 22 : 14), base = 1 + h / 7;
        for (int i = 0; i < h; i++) {
            int rad = Math.max(0, (int) Math.round(base * (1 - i / (double) h)));
            for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++)
                if (dx * dx + dz * dz <= rad * rad + (rad == 0 ? 0 : 1)) FeatureUtil.put(lvl, o.offset(dx, hanging ? -i : i, dz), ModBlocks.PIEDRA_PROFUNDA);
        }
        return true;
    }
}

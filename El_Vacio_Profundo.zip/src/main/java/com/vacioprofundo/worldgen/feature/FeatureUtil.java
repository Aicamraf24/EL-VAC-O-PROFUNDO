package com.vacioprofundo.worldgen.feature;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

final class FeatureUtil {
    private FeatureUtil() {}
    static boolean free(WorldGenLevel l, BlockPos p) {
        BlockState s = l.getBlockState(p);
        return s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty() && s.getBlock() != net.minecraft.world.level.block.Blocks.LAVA;
    }
    static void put(WorldGenLevel l, BlockPos p, Block b) { if (free(l, p)) l.setBlock(p, b.defaultBlockState(), 2); }
    static boolean solidBelow(WorldGenLevel l, BlockPos p) { return !l.getBlockState(p.below()).isAir() && l.getBlockState(p.below()).getFluidState().isEmpty(); }
}

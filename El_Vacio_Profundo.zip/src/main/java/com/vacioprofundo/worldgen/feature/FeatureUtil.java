package com.vacioprofundo.worldgen.feature;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class FeatureUtil {
    private FeatureUtil() {}
    public static boolean free(LevelAccessor l, BlockPos p) {
        BlockState s = l.getBlockState(p);
        return s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty() && s.getBlock() != net.minecraft.world.level.block.Blocks.LAVA;
    }
    public static void put(LevelAccessor l, BlockPos p, Block b) { if (free(l, p)) l.setBlock(p, b.defaultBlockState(), 2); }
    public static boolean solidBelow(LevelAccessor l, BlockPos p) { return !l.getBlockState(p.below()).isAir() && l.getBlockState(p.below()).getFluidState().isEmpty(); }
}

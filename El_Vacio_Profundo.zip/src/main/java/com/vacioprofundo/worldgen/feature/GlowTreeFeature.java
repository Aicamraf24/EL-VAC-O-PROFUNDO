package com.vacioprofundo.worldgen.feature;

import com.vacioprofundo.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Subterranean bioluminescent tree: root trunk with branches and a glowing mushroom-cap canopy. */
public class GlowTreeFeature extends Feature<NoneFeatureConfiguration> {
    public GlowTreeFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        return grow(ctx.level(), ctx.origin(), ctx.random());
    }

    /** Shared by worldgen and by the Brote Abisal (sapling). */
    public static boolean grow(LevelAccessor lvl, BlockPos o, RandomSource r) {
        if (!FeatureUtil.solidBelow(lvl, o)) return false;
        int h = 7 + r.nextInt(8);
        for (int y = 0; y < h; y++) if (!FeatureUtil.free(lvl, o.above(y))) return false;
        for (int y = 0; y < h; y++) {
            FeatureUtil.put(lvl, o.above(y), ModBlocks.RAIZ_ABISAL);
            if (y == 0) for (int[] d : new int[][]{{1,0},{-1,0},{0,1},{0,-1}}) FeatureUtil.put(lvl, o.offset(d[0], 0, d[1]), ModBlocks.RAIZ_ABISAL);
        }
        for (int b = 0; b < 4 + r.nextInt(3); b++) {
            double ang = r.nextDouble() * Math.PI * 2; int len = 3 + r.nextInt(4), by = h - 3 - r.nextInt(3);
            BlockPos p = o.above(by);
            for (int i = 1; i <= len; i++) {
                p = o.offset((int) Math.round(Math.cos(ang) * i), by + i / 2, (int) Math.round(Math.sin(ang) * i));
                FeatureUtil.put(lvl, p, ModBlocks.RAIZ_ABISAL);
            }
            blob(lvl, p, 2 + r.nextInt(2), r);
        }
        blob(lvl, o.above(h), 3, r);
        return true;
    }
    private static void blob(LevelAccessor lvl, BlockPos c, int rad, RandomSource r) {
        for (int x = -rad; x <= rad; x++) for (int y = -rad + 1; y <= rad; y++) for (int z = -rad; z <= rad; z++)
            if (x * x + y * y * 1.4 + z * z <= rad * rad + 1 && r.nextInt(5) != 0) FeatureUtil.put(lvl, c.offset(x, y, z), ModBlocks.FOLLAJE_ABISAL);
    }
}

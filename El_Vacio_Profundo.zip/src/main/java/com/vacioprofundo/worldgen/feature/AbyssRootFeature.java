package com.vacioprofundo.worldgen.feature;

import com.vacioprofundo.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Giant roots hanging from the ceiling of the Abyssal Swamp. */
public class AbyssRootFeature extends Feature<NoneFeatureConfiguration> {
    public AbyssRootFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lvl = ctx.level(); BlockPos o = ctx.origin(); RandomSource r = ctx.random();
        if (lvl.getBlockState(o.above()).isAir()) return false;
        int len = 6 + r.nextInt(18); int x = 0, z = 0;
        for (int i = 0; i < len; i++) {
            if (r.nextInt(4) == 0) x += r.nextInt(3) - 1;
            if (r.nextInt(4) == 0) z += r.nextInt(3) - 1;
            FeatureUtil.put(lvl, o.offset(x, -i, z), ModBlocks.RAIZ_ABISAL);
            if (i < 4) FeatureUtil.put(lvl, o.offset(x + 1, -i, z), ModBlocks.RAIZ_ABISAL);
        }
        return true;
    }
}

package com.vacioprofundo.worldgen.feature;

import com.vacioprofundo.registry.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Giant glowing mushroom: stem + domed cap (cyan / violet / amber), 6-16 blocks tall. */
public class GiantMushroomFeature extends Feature<NoneFeatureConfiguration> {
    public GiantMushroomFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        return grow(ctx.level(), ctx.origin(), ctx.random(), null);
    }

    /** Shared by worldgen and by Mini Hongo growth. cap == null picks a random colour. */
    public static boolean grow(LevelAccessor lvl, BlockPos o, RandomSource r, Block capBlock) {
        if (!FeatureUtil.solidBelow(lvl, o)) return false;
        int h = 6 + r.nextInt(11), rad = 3 + h / 4;
        Block cap = capBlock != null ? capBlock : switch (r.nextInt(3)) { case 0 -> ModBlocks.SOMBRERO_HONGO_CIAN; case 1 -> ModBlocks.SOMBRERO_HONGO_VIOLETA; default -> ModBlocks.SOMBRERO_HONGO_AMBAR; };
        for (int y = 0; y < h; y++) if (!FeatureUtil.free(lvl, o.above(y))) return false;
        for (int y = 0; y < h; y++) lvl.setBlock(o.above(y), ModBlocks.MADERA_HONGO.defaultBlockState(), 2);
        BlockPos top = o.above(h);
        for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++) for (int dy = 0; dy <= rad / 2 + 1; dy++) {
            double d = Math.sqrt(dx * dx + dz * dz + (dy * 1.6) * (dy * 1.6));
            if (d <= rad && d > rad - 1.6 + (dy == 0 ? 1 : 0)) FeatureUtil.put(lvl, top.offset(dx, dy - 1, dz), cap);
        }
        return true;
    }
}

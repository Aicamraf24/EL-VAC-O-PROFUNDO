package com.vacioprofundo.worldgen.structure;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.registry.ModBlocks;
import com.vacioprofundo.registry.ModEntities;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.storage.loot.LootTable;

/**
 * Procedural builders for every structure. Determinism rule: block choices use hash(x,y,z,seed), layout choices use a
 * java.util.Random seeded by the structure seed and consumed identically in every chunk pass; only blocks inside the
 * chunk box are written, so all chunks agree.
 */
final class Gen {
    private Gen() {}

    // ------------------------------------------------------------------ context
    static final class C {
        final ProcPiece piece; final WorldGenLevel lvl; final BoundingBox cb; final long seed;
        C(ProcPiece p, WorldGenLevel l, BoundingBox cb) { piece = p; lvl = l; this.cb = cb; seed = p.seed; }
        boolean in(int x, int y, int z) { return cb.isInside(new BlockPos(x, y, z)); }
        boolean touches(int x1, int z1, int x2, int z2) { return x2 >= cb.minX() && x1 <= cb.maxX() && z2 >= cb.minZ() && z1 <= cb.maxZ(); }
        void set(int x, int y, int z, BlockState s) { if (in(x, y, z)) lvl.setBlock(new BlockPos(x, y, z), s, 2); }
        void set(int x, int y, int z, Block b) { set(x, y, z, b.defaultBlockState()); }
        void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
            int ax = Math.max(Math.min(x1, x2), cb.minX()), bx = Math.min(Math.max(x1, x2), cb.maxX());
            int az = Math.max(Math.min(z1, z2), cb.minZ()), bz = Math.min(Math.max(z1, z2), cb.maxZ());
            int ay = Math.max(Math.min(y1, y2), cb.minY()), by = Math.min(Math.max(y1, y2), cb.maxY());
            BlockState s = b.defaultBlockState();
            for (int x = ax; x <= bx; x++) for (int z = az; z <= bz; z++) for (int y = ay; y <= by; y++) lvl.setBlock(new BlockPos(x, y, z), s, 2);
        }
        void fillBricks(int x1, int y1, int z1, int x2, int y2, int z2) {
            int ax = Math.max(Math.min(x1, x2), cb.minX()), bx = Math.min(Math.max(x1, x2), cb.maxX());
            int az = Math.max(Math.min(z1, z2), cb.minZ()), bz = Math.min(Math.max(z1, z2), cb.maxZ());
            int ay = Math.max(Math.min(y1, y2), cb.minY()), by = Math.min(Math.max(y1, y2), cb.maxY());
            for (int x = ax; x <= bx; x++) for (int z = az; z <= bz; z++) for (int y = ay; y <= by; y++) lvl.setBlock(new BlockPos(x, y, z), brick(x, y, z), 2);
        }
        void air(int x1, int y1, int z1, int x2, int y2, int z2) { fill(x1, y1, z1, x2, y2, z2, Blocks.AIR); }
        int h(int x, int y, int z) { return Gen.h(x, y, z, seed); }
        BlockState brick(int x, int y, int z) {
            int v = h(x, y, z) % 100;
            return (v < 58 ? ModBlocks.LADRILLO_RUINA : v < 76 ? ModBlocks.LADRILLO_RUINA_AGRIETADO : v < 92 ? ModBlocks.LADRILLO_RUINA_MUSGOSO : ModBlocks.ADOQUIN_PROFUNDO).defaultBlockState();
        }
        /** pillars/foundation: fill downward from y-1 until something solid is found (max 40). */
        void found(int x, int z, int y, Block b) {
            if (!(x >= cb.minX() && x <= cb.maxX() && z >= cb.minZ() && z <= cb.maxZ())) return;
            for (int k = 1; k <= 40; k++) {
                BlockPos p = new BlockPos(x, y - k, z);
                if (!cb.isInside(p)) break;
                BlockState s = lvl.getBlockState(p);
                if (!s.isAir() && s.getFluidState().isEmpty() && !s.canBeReplaced()) break;
                lvl.setBlock(p, b.defaultBlockState(), 2);
            }
        }
        void chest(int x, int y, int z, String table) {
            if (!in(x, y, z)) return;
            piece.chest(lvl, cb, new BlockPos(x, y, z), ResourceKey.create(Registries.LOOT_TABLE, VacioProfundo.id("chests/" + table)));
        }
        void spawner(int x, int y, int z, EntityType<?> type) {
            if (!in(x, y, z)) return;
            BlockPos p = new BlockPos(x, y, z);
            lvl.setBlock(p, Blocks.SPAWNER.defaultBlockState(), 2);
            BlockEntity be = lvl.getBlockEntity(p);
            if (be instanceof SpawnerBlockEntity sbe) sbe.setEntityId(type, net.minecraft.util.RandomSource.create(seed ^ p.asLong()));
        }
        void ladder(int x, int y1, int y2, int z, Direction face) {
            for (int y = y1; y <= y2; y++) set(x, y, z, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, face));
        }
    }
    static int h(int x, int y, int z, long seed) {
        long v = x * 341873128712L + y * 132897987541L + z * 42317861L + seed;
        v = (v ^ (v >>> 13)) * 1274126177L; v ^= v >>> 16;
        return (int) (v & 0x7fffffff);
    }
    static boolean decay(C c, int x, int y, int z, int pct) { return c.h(x, y * 7, z) % 100 < pct; }

    // ------------------------------------------------------------------ entry
    static void build(ProcPiece p, WorldGenLevel level, BoundingBox box) {
        C c = new C(p, level, box);
        int x = p.cx, y = p.cy, z = p.cz;
        Random r = new Random(p.seed);
        switch (p.kind) {
            case "city" -> city(c, x, y, z, r, false);
            case "city2" -> city(c, x, y, z, r, true);
            case "sanctuary" -> sanctuary(c, x, y, z);
            case "temple" -> temple(c, x, y, z);
            case "library" -> library(c, x, y, z, 15, 11);
            case "lab" -> lab(c, x, y, z);
            case "mine" -> mine(c, x, y, z);
            case "statue" -> statue(c, x, y, z);
            case "vault" -> vault(c, x, y, z);
            case "prison" -> prison(c, x, y, z);
            case "altar" -> altar(c, x, y, z);
            case "camp" -> camp(c, x, y, z);
            case "watchtower" -> tower(c, x, y, z, 3, 12, true);
            case "ruin" -> ruin(c, x, y, z);
            case "outpost" -> outpost(c, x, y, z);
            case "cave" -> cave(c, x, y, z);
            default -> ruin(c, x, y, z);
        }
    }

    // ------------------------------------------------------------------ small pieces
    static void tower(C c, int x, int y, int z, int R, int H, boolean watch) {
        if (!c.touches(x - R - 1, z - R - 1, x + R + 1, z + R + 1)) return;
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            int px = x + dx, pz = z + dz;
            if (d > R + 0.4) continue;
            c.found(px, pz, y, ModBlocks.LADRILLO_RUINA);
            c.set(px, y, pz, ModBlocks.BALDOSA_ANTIGUA);
            boolean wall = d > R - 0.9;
            int top = H - (wall && !watch ? c.h(px, 0, pz) % 5 : 0);
            for (int yy = 1; yy <= H; yy++) {
                if (wall) {
                    boolean door = dz > 0 && Math.abs(dx) <= 1 && yy <= 3;
                    boolean window = !door && yy % 5 == 3 && (Math.abs(dx) + Math.abs(dz)) % 3 == 0;
                    if (yy > top || door || window) c.set(px, y + yy, pz, Blocks.AIR); else c.set(px, y + yy, pz, c.brick(px, y + yy, pz));
                } else {
                    c.set(px, y + yy, pz, Blocks.AIR);
                }
            }
            if (!wall && !watch) for (int fl = 6; fl < H; fl += 6) if (!(dx > 0 && dz < 0 && d < R - 1.5)) c.set(px, y + fl, pz, ModBlocks.BALDOSA_ANTIGUA);
            if (wall && watch && (dx + dz) % 2 == 0) c.set(px, y + H + 1, pz, ModBlocks.LADRILLO_RUINA);
        }
        if (watch) { c.ladder(x, y + 1, y + H, z - R + 1, Direction.SOUTH); c.set(x, y + H, z - R + 1, Blocks.AIR); }
        c.set(x, y + 1, z, Blocks.SOUL_LANTERN);
        c.chest(x - R + 1, y + (watch ? H + 1 : Math.max(1, H - H % 6) + 1), z + 1, "comun");
        if (!watch && H >= 14) c.spawner(x + 1, y + 1, z, ModEntities.GUARDIAN_RUINAS);
    }

    static void ruin(C c, int x, int y, int z) {
        Random r = new Random(c.seed);
        for (int i = 0; i < 7; i++) {
            int ox = x + r.nextInt(17) - 8, oz = z + r.nextInt(17) - 8, len = 3 + r.nextInt(6), hgt = 2 + r.nextInt(5); boolean alongX = r.nextBoolean();
            if (!c.touches(ox - 1, oz - 1, ox + len + 1, oz + len + 1)) continue;
            for (int k = 0; k < len; k++) {
                int px = alongX ? ox + k : ox, pz = alongX ? oz : oz + k;
                c.found(px, pz, y, ModBlocks.ADOQUIN_PROFUNDO);
                int top = hgt - c.h(px, 1, pz) % 3;
                for (int yy = 0; yy <= top; yy++) c.set(px, y + yy, pz, c.brick(px, y + yy, pz));
            }
        }
        c.set(x, y, z, ModBlocks.BALDOSA_ANTIGUA); c.chest(x, y + 1, z, "ruinas");
        c.set(x + 2, y, z, ModBlocks.CRISTAL_LUMINOSO_CIAN);
    }

    static void camp(C c, int x, int y, int z) {
        if (!c.touches(x - 8, z - 8, x + 8, z + 8)) return;
        c.fill(x - 6, y, z - 6, x + 6, y, z + 6, ModBlocks.TIERRA_PROFUNDA); c.air(x - 6, y + 1, z - 6, x + 6, y + 5, z + 6);
        for (int s : new int[]{-1, 1}) {
            int tx = x + s * 4;
            for (int k = 0; k < 3; k++) for (int dz = -2; dz <= 2; dz++) { c.set(tx - 2 + k, y + 1 + k, z + dz, Blocks.BROWN_WOOL); c.set(tx + 2 - k, y + 1 + k, z + dz, Blocks.BROWN_WOOL); }
            c.air(tx - 1, y + 1, z - 1, tx + 1, y + 2, z + 1);
            c.set(tx, y + 1, z, Blocks.RED_BED);
        }
        c.set(x, y + 1, z, Blocks.CAMPFIRE.defaultBlockState().setValue(net.minecraft.world.level.block.CampfireBlock.LIT, false));
        c.set(x + 1, y + 1, z + 3, Blocks.BARREL); c.set(x - 1, y + 1, z + 3, Blocks.TORCH);
        c.chest(x, y + 1, z - 4, "comun");
        c.set(x + 3, y + 1, z - 3, ModBlocks.RACIMO_CRISTAL_CIAN);
    }

    static void outpost(C c, int x, int y, int z) {
        if (!c.touches(x - 7, z - 7, x + 7, z + 7)) return;
        for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) { c.found(x + dx, z + dz, y, ModBlocks.ADOQUIN_PROFUNDO); c.set(x + dx, y, z + dz, ModBlocks.BALDOSA_ANTIGUA); }
        c.air(x - 5, y + 1, z - 5, x + 5, y + 6, z + 5);
        for (int[] q : new int[][]{{-5, -5}, {5, -5}, {-5, 5}, {5, 5}}) { for (int yy = 1; yy <= 4; yy++) c.set(x + q[0], y + yy, z + q[1], ModBlocks.LADRILLO_RUINA); c.set(x + q[0], y + 5, z + q[1], Blocks.LANTERN); }
        c.fill(x - 2, y + 1, z - 2, x + 2, y + 1, z - 2, Blocks.OAK_FENCE);
        c.set(x, y + 1, z + 2, Blocks.BARREL); c.set(x + 2, y + 1, z + 2, Blocks.CRAFTING_TABLE);
        c.chest(x - 3, y + 1, z - 3, "comun");
    }

    static void cave(C c, int x, int y, int z) {
        if (!c.touches(x - 7, z - 7, x + 7, z + 7)) return;
        for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) for (int dy = 0; dy <= 6; dy++) {
            double d = Math.sqrt(dx * dx + dz * dz + dy * dy * 1.6);
            if (d <= 6 && d > 4.3) c.set(x + dx, y + dy, z + dz, ModBlocks.PIEDRA_PROFUNDA);
            else if (d <= 4.3 && dy > 0) c.set(x + dx, y + dy, z + dz, Blocks.AIR);
        }
        c.air(x - 1, y + 1, z + 3, x + 1, y + 3, z + 7);
        c.set(x, y + 1, z - 2, ModBlocks.RACIMO_CRISTAL_VIOLETA); c.set(x - 2, y + 1, z - 1, ModBlocks.RACIMO_CRISTAL_CIAN); c.set(x + 2, y + 1, z - 1, ModBlocks.RACIMO_CRISTAL_AMBAR);
        c.chest(x, y + 1, z, "tesoro");
    }

    // ------------------------------------------------------------------ big pieces
    static void room(C c, int x1, int z1, int x2, int z2, int y, int H, boolean pillars) {
        if (!c.touches(x1 - 1, z1 - 1, x2 + 1, z2 + 1)) return;
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) {
            c.found(x, z, y, ModBlocks.ADOQUIN_PROFUNDO); c.set(x, y, z, ModBlocks.BALDOSA_ANTIGUA);
            boolean wall = x == x1 || x == x2 || z == z1 || z == z2;
            int mid = (x1 + x2) / 2;
            for (int yy = 1; yy <= H; yy++) {
                if (wall) {
                    boolean door = z == z2 && Math.abs(x - mid) <= 1 && yy <= 3;
                    boolean win = !door && yy >= 3 && yy <= 5 && ((x + z) % 4 == 0);
                    int top = H - c.h(x, 2, z) % 4;
                    if (door || win || yy > top) c.set(x, y + yy, z, Blocks.AIR); else c.set(x, y + yy, z, c.brick(x, y + yy, z));
                } else if (pillars && (x - x1) % 4 == 2 && (z - z1) % 4 == 2) c.set(x, y + yy, z, c.brick(x, y + yy, z));
                else c.set(x, y + yy, z, Blocks.AIR);
            }
            if (!wall && c.h(x, 3, z) % 100 < 70) c.set(x, y + H + 1, z, ModBlocks.LADRILLO_RUINA);   // partly collapsed roof
        }
    }
    static void hall(C c, int x, int y, int z, int w, int l) {
        room(c, x - w / 2, z - l / 2, x + w / 2, z + l / 2, y, 8, true);
        c.set(x, y + 1, z, Blocks.SOUL_LANTERN);
        c.chest(x - w / 2 + 1, y + 1, z - l / 2 + 1, "ruinas");
        c.set(x + w / 2 - 1, y + 1, z - l / 2 + 1, ModBlocks.CRISTAL_LUMINOSO_VIOLETA);
    }
    static void library(C c, int x, int y, int z, int w, int l) {
        room(c, x - w / 2, z - l / 2, x + w / 2, z + l / 2, y, 7, false);
        if (!c.touches(x - w / 2, z - l / 2, x + w / 2, z + l / 2)) return;
        for (int xx = x - w / 2 + 2; xx <= x + w / 2 - 2; xx += 3) for (int zz = z - l / 2 + 2; zz <= z + l / 2 - 3; zz++) {
            if ((zz + xx) % 5 == 0) continue;
            c.set(xx, y + 1, zz, Blocks.BOOKSHELF); c.set(xx, y + 2, zz, Blocks.BOOKSHELF);
            if (c.h(xx, 9, zz) % 3 == 0) c.set(xx, y + 3, zz, Blocks.COBWEB);
        }
        c.chest(x, y + 1, z - l / 2 + 1, "biblioteca"); c.chest(x + 2, y + 1, z - l / 2 + 1, "biblioteca");
    }
    static void lab(C c, int x, int y, int z) {
        room(c, x - 6, z - 5, x + 6, z + 5, y, 6, false);
        if (!c.touches(x - 6, z - 5, x + 6, z + 5)) return;
        c.set(x - 4, y + 1, z - 3, Blocks.BREWING_STAND); c.set(x - 2, y + 1, z - 4, Blocks.CAULDRON); c.set(x + 2, y + 1, z - 4, Blocks.SMITHING_TABLE);
        for (int i = -5; i <= 5; i += 2) c.set(x + i, y + 2, z + 4, Blocks.GLASS_PANE);
        c.fill(x + 3, y + 1, z + 2, x + 5, y + 3, z + 2, Blocks.IRON_BARS);
        c.set(x, y + 1, z, ModBlocks.CRISTAL_LUMINOSO_CIAN);
        c.chest(x + 4, y + 1, z - 3, "laboratorio");
        c.spawner(x - 4, y + 1, z + 3, ModEntities.ESPECTRO_CRISTAL);
    }
    static void temple(C c, int x, int y, int z) {
        if (!c.touches(x - 16, z - 16, x + 16, z + 16)) return;
        int[] rad = {14, 11, 8};
        for (int t = 0; t < 3; t++) for (int dx = -rad[t]; dx <= rad[t]; dx++) for (int dz = -rad[t]; dz <= rad[t]; dz++) {
            c.found(x + dx, z + dz, y, ModBlocks.ADOQUIN_PROFUNDO);
            for (int yy = 0; yy <= t * 2 + 1; yy++) c.set(x + dx, y + yy, z + dz, c.brick(x + dx, y + yy, z + dz));
            for (int yy = t * 2 + 2; yy <= 16; yy++) c.set(x + dx, y + yy, z + dz, Blocks.AIR);
        }
        for (int k = 0; k < 8; k++) {
            int px = x + (int) Math.round(Math.cos(k * Math.PI / 4) * 6.5), pz = z + (int) Math.round(Math.sin(k * Math.PI / 4) * 6.5);
            int hgt = 9 - c.h(px, 4, pz) % 4;
            for (int yy = 6; yy <= 6 + hgt; yy++) c.set(px, y + yy, pz, c.brick(px, y + yy, pz));
            c.set(px, y + 7 + hgt, pz, ModBlocks.CRISTAL_LUMINOSO_VIOLETA);
        }
        c.fill(x - 1, y + 6, z - 1, x + 1, y + 6, z + 1, ModBlocks.OBSIDIANA_VOLCANICA); c.set(x, y + 7, z, Blocks.CRYING_OBSIDIAN);
        c.chest(x, y + 6, z + 3, "ruinas");
        c.spawner(x, y + 6, z - 3, ModEntities.GUARDIAN_RUINAS);
    }
    static void mine(C c, int x, int y, int z) {
        if (!c.touches(x - 34, z - 3, x + 34, z + 3)) return;
        for (int dx = -32; dx <= 32; dx++) {
            c.found(x + dx, z, y, Blocks.COBBLESTONE);
            for (int dz = -1; dz <= 1; dz++) { c.set(x + dx, y, z + dz, ModBlocks.PIEDRA_PROFUNDA); c.air(x + dx, y + 1, z + dz, x + dx, y + 3, z + dz); c.set(x + dx, y + 4, z + dz, ModBlocks.PIEDRA_PROFUNDA); }
            c.set(x + dx, y + 1, z, Blocks.RAIL);
            c.set(x + dx, y, z - 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 1, z - 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 2, z - 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 3, z - 2, ModBlocks.PIEDRA_PROFUNDA);
            c.set(x + dx, y, z + 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 1, z + 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 2, z + 2, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y + 3, z + 2, ModBlocks.PIEDRA_PROFUNDA);
            if (dx % 4 == 0) { for (int yy = 1; yy <= 3; yy++) { c.set(x + dx, y + yy, z - 1, Blocks.OAK_FENCE); c.set(x + dx, y + yy, z + 1, Blocks.OAK_FENCE); } c.set(x + dx, y + 4, z, Blocks.OAK_PLANKS); }
            if (dx % 8 == 3) c.set(x + dx, y + 3, z, Blocks.LANTERN.defaultBlockState().setValue(net.minecraft.world.level.block.LanternBlock.HANGING, true));
            if (c.h(x + dx, 5, z) % 11 == 0) c.set(x + dx, y + 2, z + 2, ModBlocks.MINERAL_CUARZO_PROFUNDO);
        }
        c.chest(x + 31, y + 1, z + 1, "mina"); c.chest(x - 31, y + 1, z - 1, "mina");
        c.spawner(x, y + 1, z + 1, ModEntities.CIEMPIES_COLOSAL);
    }
    static void statue(C c, int x, int y, int z) {
        if (!c.touches(x - 12, z - 10, x + 12, z + 10)) return;
        for (int dx = -9; dx <= 9; dx++) for (int dz = -7; dz <= 7; dz++) { c.found(x + dx, z + dz, y, ModBlocks.ADOQUIN_PROFUNDO); c.fillBricks(x + dx, y, z + dz, x + dx, y + 1, z + dz); }
        int b = y + 2;
        c.fillBricks(x - 5, b, z - 3, x - 1, b + 11, z + 3); c.fillBricks(x + 1, b, z - 3, x + 5, b + 11, z + 3);                // legs
        c.fillBricks(x - 6, b + 12, z - 4, x + 6, b + 25, z + 4);                                                                // torso
        c.fillBricks(x - 10, b + 14, z - 3, x - 7, b + 24, z + 3); c.fillBricks(x + 7, b + 14, z - 3, x + 10, b + 24, z + 3);  // arms
        c.fillBricks(x - 4, b + 26, z - 4, x + 4, b + 33, z + 4);                                                                // head
        c.fill(x - 3, b + 30, z + 4, x - 2, b + 30, z + 4, ModBlocks.CRISTAL_LUMINOSO_CIAN); c.fill(x + 2, b + 30, z + 4, x + 3, b + 30, z + 4, ModBlocks.CRISTAL_LUMINOSO_CIAN);
        c.fill(x - 1, b + 20, z + 4, x + 1, b + 22, z + 4, ModBlocks.CRISTAL_LUMINOSO_VIOLETA);
        c.fillBricks(x - 3, b + 34, z - 3, x + 3, b + 35, z + 3);
        c.air(x - 1, b, z + 3, x + 1, b + 2, z + 3); c.chest(x, b, z, "tesoro");   // hollow hidden chamber in the legs
    }
    static void vault(C c, int x, int y, int z) {
        if (!c.touches(x - 9, z - 9, x + 9, z + 9)) return;
        for (int dx = -8; dx <= 8; dx++) for (int dz = -8; dz <= 8; dz++) {
            c.found(x + dx, z + dz, y, ModBlocks.OBSIDIANA_VOLCANICA);
            boolean wall = Math.abs(dx) == 8 || Math.abs(dz) == 8;
            for (int yy = 0; yy <= 7; yy++) {
                if (yy == 0 || yy == 7) c.set(x + dx, y + yy, z + dz, ModBlocks.OBSIDIANA_VOLCANICA);
                else if (wall) c.set(x + dx, y + yy, z + dz, (yy == 4 && (dx + dz) % 3 == 0) ? Blocks.IRON_BARS.defaultBlockState() : ModBlocks.OBSIDIANA_VOLCANICA.defaultBlockState());
                else c.set(x + dx, y + yy, z + dz, Blocks.AIR);
            }
        }
        c.set(x, y + 1, z + 8, ModBlocks.LADRILLO_RUINA_AGRIETADO); c.set(x, y + 2, z + 8, ModBlocks.LADRILLO_RUINA_AGRIETADO);   // secret door
        for (int[] q : new int[][]{{-5, -5}, {5, -5}, {-5, 5}, {5, 5}}) c.chest(x + q[0], y + 1, z + q[1], "tesoro");
        c.spawner(x - 2, y + 1, z, ModEntities.GUARDIAN_RUINAS); c.spawner(x + 2, y + 1, z, ModEntities.GUARDIAN_RUINAS);
        c.set(x, y + 1, z, ModBlocks.CRISTAL_LUMINOSO_AMBAR);
    }
    static void prison(C c, int x, int y, int z) {
        room(c, x - 10, z - 7, x + 10, z + 7, y, 6, false);
        if (!c.touches(x - 10, z - 7, x + 10, z + 7)) return;
        for (int side : new int[]{-1, 1}) for (int cell = -8; cell <= 6; cell += 4) {
            int cx = x + cell, cz = z + side * 5;
            for (int yy = 1; yy <= 3; yy++) { c.set(cx, y + yy, z + side * 2, Blocks.IRON_BARS); c.set(cx + 1, y + yy, z + side * 2, Blocks.IRON_BARS); c.set(cx + 3, y + yy, z + side * 5, ModBlocks.LADRILLO_RUINA); }
            c.set(cx + 1, y + 1, cz, Blocks.HAY_BLOCK);
        }
        c.chest(x - 9, y + 1, z, "mina"); c.spawner(x + 9, y + 1, z, ModEntities.GUARDIAN_RUINAS);
    }
    static void altar(C c, int x, int y, int z) {
        if (!c.touches(x - 8, z - 8, x + 8, z + 8)) return;
        for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz); if (d > 6) continue;
            c.found(x + dx, z + dz, y, ModBlocks.PIEDRA_PROFUNDA); c.set(x + dx, y, z + dz, d > 4.5 ? ModBlocks.OBSIDIANA_VOLCANICA : ModBlocks.BALDOSA_ANTIGUA);
            c.air(x + dx, y + 1, z + dz, x + dx, y + 8, z + dz);
        }
        for (int[] q : new int[][]{{-5, 0}, {5, 0}, {0, -5}, {0, 5}}) { c.fill(x + q[0], y + 1, z + q[1], x + q[0], y + 5, z + q[1], ModBlocks.CRISTAL_OSCURO_VIOLETA); c.set(x + q[0], y + 6, z + q[1], ModBlocks.CRISTAL_LUMINOSO_VIOLETA); }
        c.fill(x - 1, y + 1, z - 1, x + 1, y + 1, z + 1, ModBlocks.OBSIDIANA_VOLCANICA); c.set(x, y + 2, z, Blocks.CRYING_OBSIDIAN);
        c.chest(x, y + 2, z + 1, "ruinas");
    }

    // ------------------------------------------------------------------ bridges
    static void bridgeLine(C c, int x1, int z1, int x2, int z2, int y) {
        int steps = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1));
        if (steps == 0 || !c.touches(Math.min(x1, x2) - 3, Math.min(z1, z2) - 3, Math.max(x1, x2) + 3, Math.max(z1, z2) + 3)) return;
        double nx = -(double) (z2 - z1) / Math.hypot(x2 - x1, z2 - z1), nz = (double) (x2 - x1) / Math.hypot(x2 - x1, z2 - z1);
        for (int i = 0; i <= steps; i++) {
            int px = x1 + (int) Math.round((x2 - x1) * (i / (double) steps)), pz = z1 + (int) Math.round((z2 - z1) * (i / (double) steps));
            for (int w = -1; w <= 1; w++) {
                int bx = px + (int) Math.round(nx * w), bz = pz + (int) Math.round(nz * w);
                if (c.h(bx, 11, bz) % 100 < 6) continue;
                c.set(bx, y, bz, ModBlocks.BALDOSA_ANTIGUA); c.air(bx, y + 1, bz, bx, y + 3, bz);
                if (w != 0 && i % 2 == 0 && c.h(bx, 12, bz) % 100 < 85) c.set(bx, y + 1, bz, ModBlocks.LADRILLO_RUINA);
            }
            if (i % 9 == 4) c.set(px, y + 2, pz, Blocks.SOUL_LANTERN);
        }
    }

    // ------------------------------------------------------------------ city
    record B(String type, int x, int z, int r) {}
    static void city(C c, int cx, int cy, int cz, Random r, boolean island) {
        // layout (deterministic, identical in every chunk pass)
        List<B> bl = new ArrayList<>();
        bl.add(new B("plaza", cx, cz, 9));
        boolean vault = false, statue = false;
        for (int attempt = 0; attempt < 90 && bl.size() < 17; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2, dist = 14 + r.nextDouble() * 38;
            int bx = cx + (int) (Math.cos(ang) * dist), bz = cz + (int) (Math.sin(ang) * dist);
            int roll = r.nextInt(100); String t; int rad;
            if (roll < 30) { t = "tower"; rad = 4 + r.nextInt(3); }
            else if (roll < 50) { t = "hall"; rad = 8; }
            else if (roll < 60) { t = "library"; rad = 8; }
            else if (roll < 68) { t = "lab"; rad = 7; }
            else if (roll < 76) { t = "temple"; rad = 15; }
            else if (roll < 83) { t = "prison"; rad = 11; }
            else if (roll < 89 && !statue) { t = "statue"; rad = 11; statue = true; }
            else if (roll < 95 && !vault) { t = "vault"; rad = 9; vault = true; }
            else { t = "altar"; rad = 7; }
            boolean ok = true;
            for (B o : bl) if (Math.hypot(o.x() - bx, o.z() - bz) < o.r() + rad + 3) { ok = false; break; }
            if (ok) bl.add(new B(t, bx, bz, rad));
        }
        int towerH = 14 + r.nextInt(14);
        if (island && c.touches(cx - 56, cz - 56, cx + 56, cz + 56)) {
            for (int dx = -56; dx <= 56; dx++) for (int dz = -56; dz <= 56; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz); if (d > 56) continue;
                int depth = (int) ((1 - d / 56.0) * 30) + 2 + c.h(cx + dx, 3, cz + dz) % 3;
                for (int k = 0; k < depth; k++) c.set(cx + dx, cy - k, cz + dz, k == 0 ? ModBlocks.BALDOSA_ANTIGUA : (k < 3 ? ModBlocks.TIERRA_PROFUNDA : ModBlocks.PIEDRA_PROFUNDA).defaultBlockState());
                c.air(cx + dx, cy + 1, cz + dz, cx + dx, cy + 30, cz + dz);
            }
        }
        // roads (plaza -> each building), drawn as L paths
        for (B b : bl) {
            if (b.type().equals("plaza")) continue;
            int x1 = Math.min(cx, b.x()), x2 = Math.max(cx, b.x()), z1 = Math.min(cz, b.z()), z2 = Math.max(cz, b.z());
            if (!c.touches(x1 - 2, z1 - 2, x2 + 2, z2 + 2)) continue;
            for (int x = x1; x <= x2; x++) for (int w = -1; w <= 1; w++) road(c, x, cz + w, cy, island);
            for (int z = z1; z <= z2; z++) for (int w = -1; w <= 1; w++) road(c, b.x() + w, z, cy, island);
        }
        // plaza
        if (c.touches(cx - 10, cz - 10, cx + 10, cz + 10)) {
            for (int dx = -9; dx <= 9; dx++) for (int dz = -9; dz <= 9; dz++) if (dx * dx + dz * dz <= 81) { if (!island) c.found(cx + dx, cz + dz, cy, ModBlocks.ADOQUIN_PROFUNDO); c.set(cx + dx, cy, cz + dz, (dx + dz) % 2 == 0 ? ModBlocks.BALDOSA_ANTIGUA : ModBlocks.LADRILLO_RUINA); c.air(cx + dx, cy + 1, cz + dz, cx + dx, cy + 12, cz + dz); }
            c.fill(cx - 1, cy + 1, cz - 1, cx + 1, cy + 1, cz + 1, ModBlocks.OBSIDIANA_VOLCANICA); c.fill(cx, cy + 2, cz, cx, cy + 9, cz, ModBlocks.CRISTAL_OSCURO_VIOLETA); c.set(cx, cy + 10, cz, ModBlocks.CRISTAL_LUMINOSO_VIOLETA);
            c.chest(cx + 3, cy + 1, cz + 3, "comun");
        }
        List<B> towers = new ArrayList<>();
        for (B b : bl) {
            int x = b.x(), z = b.z(), y = cy;
            switch (b.type()) {
                case "tower" -> { tower(c, x, y, z, b.r(), towerH - (x % 5), false); towers.add(b); }
                case "hall" -> hall(c, x, y, z, 13 + (x & 3) * 2, 11 + (z & 3) * 2);
                case "library" -> library(c, x, y, z, 15, 11);
                case "lab" -> lab(c, x, y, z);
                case "temple" -> temple(c, x, y, z);
                case "prison" -> prison(c, x, y, z);
                case "statue" -> statue(c, x, y, z);
                case "vault" -> vault(c, x, y, z);
                case "altar" -> altar(c, x, y, z);
                default -> { }
            }
        }
        for (int i = 0; i + 1 < towers.size(); i++) {
            B a = towers.get(i), b = towers.get(i + 1);
            double d = Math.hypot(a.x() - b.x(), a.z() - b.z());
            if (d > 10 && d < 40) bridgeLine(c, a.x(), a.z(), b.x(), b.z(), cy + 11);
        }
        // broken perimeter wall (iterates only this chunk's columns)
        int R = 60;
        for (int x = c.cb.minX(); x <= c.cb.maxX(); x++) for (int z = c.cb.minZ(); z <= c.cb.maxZ(); z++) {
            double d = Math.hypot(x - cx, z - cz);
            if (d < R - 0.8 || d > R + 0.8 || island) continue;
            int hgt = 3 + c.h(x, 8, z) % 6;
            if (c.h(x / 6, 9, z / 6) % 100 < 22) continue;     // gaps
            c.found(x, z, cy, ModBlocks.ADOQUIN_PROFUNDO);
            for (int yy = 0; yy <= hgt; yy++) c.set(x, cy + yy, z, c.brick(x, cy + yy, z));
            if (c.h(x, 10, z) % 100 < 5) c.set(x, cy + hgt + 1, z, Blocks.SOUL_LANTERN);
        }
    }
    static void road(C c, int x, int z, int y, boolean island) {
        if (!c.in(x, y, z)) return;
        if (!island) c.found(x, z, y, ModBlocks.ADOQUIN_PROFUNDO);
        c.set(x, y, z, c.h(x, 13, z) % 5 == 0 ? ModBlocks.ADOQUIN_PROFUNDO : ModBlocks.BALDOSA_ANTIGUA);
        c.air(x, y + 1, z, x, y + 4, z);
    }

    // ------------------------------------------------------------------ sanctuary + boss
    static void sanctuary(C c, int cx, int cy, int cz) {
        if (!c.touches(cx - 34, cz - 34, cx + 34, cz + 34)) return;
        for (int dx = -32; dx <= 32; dx++) for (int dz = -32; dz <= 32; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz); if (d > 31) continue;
            int x = cx + dx, z = cz + dz;
            c.found(x, z, cy, ModBlocks.OBSIDIANA_VOLCANICA);
            Block floor = d < 6 ? ModBlocks.OBSIDIANA_VOLCANICA : ((int) d % 6 == 0 ? ModBlocks.PIEDRA_CRISTAL_OSCURO : ModBlocks.BALDOSA_ANTIGUA);
            c.set(x, cy, z, floor);
            if (d < 28) c.air(x, cy + 1, z, x, cy + 24, z);
            if (d >= 28 && d <= 30.5) {
                boolean gate = Math.abs(dx) <= 3 || Math.abs(dz) <= 3;
                for (int yy = 1; yy <= 16; yy++) { if (gate && yy <= 8) c.set(x, cy + yy, z, Blocks.AIR); else c.set(x, cy + yy, z, yy % 4 == 0 && (dx + dz) % 5 == 0 ? ModBlocks.CRISTAL_LUMINOSO_VIOLETA.defaultBlockState() : ModBlocks.OBSIDIANA_VOLCANICA.defaultBlockState()); }
            }
            if (d < 6) c.set(x, cy + 1, z, d < 4.5 ? ModBlocks.OBSIDIANA_VOLCANICA : ModBlocks.PIEDRA_CRISTAL_OSCURO);   // central dais
        }
        for (int k = 0; k < 8; k++) {
            int px = cx + (int) Math.round(Math.cos(k * Math.PI / 4 + 0.39) * 19), pz = cz + (int) Math.round(Math.sin(k * Math.PI / 4 + 0.39) * 19);
            for (int yy = 1; yy <= 17; yy++) { c.set(px, cy + yy, pz, ModBlocks.PIEDRA_CRISTAL_OSCURO); c.set(px + 1, cy + yy, pz, ModBlocks.PIEDRA_CRISTAL_OSCURO); c.set(px, cy + yy, pz + 1, ModBlocks.PIEDRA_CRISTAL_OSCURO); c.set(px + 1, cy + yy, pz + 1, ModBlocks.PIEDRA_CRISTAL_OSCURO); }
            c.fill(px, cy + 18, pz, px + 1, cy + 19, pz + 1, ModBlocks.CRISTAL_LUMINOSO_VIOLETA);
        }
        c.fill(cx - 2, cy + 2, cz - 2, cx + 2, cy + 2, cz + 2, ModBlocks.BLOQUE_OBSIDIANA_VIVIENTE);
        for (int[] q : new int[][]{{-14, -22}, {-5, -24}, {5, -24}, {14, -22}}) { c.fill(cx + q[0] - 1, cy + 1, cz + q[1] - 1, cx + q[0] + 1, cy + 1, cz + q[1] + 1, ModBlocks.OBSIDIANA_VOLCANICA); c.chest(cx + q[0], cy + 2, cz + q[1], "santuario"); }
        for (int[] q : new int[][]{{-12, 12}, {12, 12}, {0, -14}}) c.spawner(cx + q[0], cy + 1, cz + q[1], ModEntities.DEVORADOR_ALMAS);
        // the king sleeps on the dais; spawned once, when the chunk holding the center is generated
        if (c.in(cx, cy + 3, cz) && c.lvl.getLevel() != null) {
            var king = ModEntities.REY_ABISMO.create(c.lvl.getLevel(), EntitySpawnReason.STRUCTURE);
            if (king != null) { king.setPos(cx + 0.5, cy + 3, cz + 0.5); if (king instanceof Mob m) m.setPersistenceRequired(); c.lvl.addFreshEntity(king); }
        }
    }
}

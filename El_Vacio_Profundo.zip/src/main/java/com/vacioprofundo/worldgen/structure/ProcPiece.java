package com.vacioprofundo.worldgen.structure;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Single piece holding the whole structure; blocks are produced deterministically per chunk (see Gen). */
public class ProcPiece extends StructurePiece {
    final String kind; final long seed; final int cx, cy, cz, radius;

    public ProcPiece(String kind, long seed, int cx, int cy, int cz, int radius, BoundingBox bb) {
        super(ModStructures.PIECE, 0, bb);
        this.kind = kind; this.seed = seed; this.cx = cx; this.cy = cy; this.cz = cz; this.radius = radius;
    }
    public ProcPiece(CompoundTag tag) {
        super(ModStructures.PIECE, tag);
        kind = tag.getStringOr("kind", "ruin"); seed = tag.getLongOr("seed", 0L);
        cx = tag.getIntOr("cx", 0); cy = tag.getIntOr("cy", 0); cz = tag.getIntOr("cz", 0); radius = tag.getIntOr("r", 12);
    }
    @Override protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag tag) {
        tag.putString("kind", kind); tag.putLong("seed", seed); tag.putInt("cx", cx); tag.putInt("cy", cy); tag.putInt("cz", cz); tag.putInt("r", radius);
    }
    @Override
    public void postProcess(WorldGenLevel level, StructureManager sm, ChunkGenerator gen, RandomSource rnd, BoundingBox box, ChunkPos cp, BlockPos pivot) {
        Gen.build(this, level, box);
    }
    // exposed for Gen (createChest is protected in StructurePiece)
    boolean chest(WorldGenLevel l, BoundingBox box, BlockPos p, net.minecraft.resources.ResourceKey<net.minecraft.world.level.storage.loot.LootTable> loot) {
        return createChest(l, box, RandomSource.create(seed ^ p.asLong()), p, loot, null);
    }
}

package com.vacioprofundo.worldgen.structure;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** One structure type for all 16 procedural structures; the "variant" string (set in JSON) selects the builder. */
public class VacioStructure extends Structure {
    public static final MapCodec<VacioStructure> CODEC = RecordCodecBuilder.mapCodec(i ->
        i.group(settingsCodec(i), Codec.STRING.fieldOf("variant").forGetter(s -> s.variant)).apply(i, VacioStructure::new));
    private static final Map<String, Integer> RADIUS = Map.ofEntries(Map.entry("city", 62), Map.entry("city2", 62), Map.entry("sanctuary", 36),
        Map.entry("temple", 20), Map.entry("library", 18), Map.entry("lab", 16), Map.entry("mine", 36), Map.entry("statue", 20), Map.entry("vault", 14),
        Map.entry("prison", 20), Map.entry("altar", 10), Map.entry("camp", 10), Map.entry("watchtower", 6), Map.entry("ruin", 14), Map.entry("outpost", 10), Map.entry("cave", 8));
    private final String variant;

    public VacioStructure(Structure.StructureSettings settings, String variant) { super(settings); this.variant = variant; }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext ctx) {
        ChunkPos cp = ctx.chunkPos();
        int x = cp.getMiddleBlockX(), z = cp.getMiddleBlockZ();
        NoiseColumn col = ctx.chunkGenerator().getBaseColumn(x, z, ctx.heightAccessor(), ctx.randomState());
        int floor = Integer.MIN_VALUE;
        for (int y = 150; y > -40; y--) {
            BlockState s = col.getBlock(y);
            if (!s.isAir() && s.getFluidState().isEmpty() && col.getBlock(y + 1).isAir() && col.getBlock(y + 2).isAir()) { floor = y; break; }
        }
        if (floor == Integer.MIN_VALUE) return Optional.empty();
        int r = RADIUS.getOrDefault(variant, 12);
        int y0 = variant.equals("city2") ? Math.min(floor + 30, 110) : floor;
        long seed = ctx.seed() ^ ((long) x * 341873128712L + (long) z * 132897987541L);
        BoundingBox bb = new BoundingBox(x - r, y0 - 36, z - r, x + r, y0 + 48, z + r);
        return Optional.of(new GenerationStub(new BlockPos(x, y0, z), b -> b.addPiece(new ProcPiece(variant, seed, x, y0, z, r, bb))));
    }

    @Override public StructureType<?> type() { return ModStructures.PROCEDURAL; }
}

package com.vacioprofundo.worldgen.structure;

import com.vacioprofundo.VacioProfundo;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.StructureType;

public final class ModStructures {
    private ModStructures() {}
    public static StructureType<VacioStructure> PROCEDURAL;
    public static StructurePieceType PIECE;
    public static void init() {
        PROCEDURAL = Registry.register(BuiltInRegistries.STRUCTURE_TYPE, VacioProfundo.id("procedural"), () -> VacioStructure.CODEC);
        PIECE = Registry.register(BuiltInRegistries.STRUCTURE_PIECE, VacioProfundo.id("proc"), (StructurePieceType.ContextlessType) ProcPiece::new);
    }
}

package com.vacioprofundo.item;

import com.vacioprofundo.portal.PortalHandler;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** Activates a Void Frame (Marco del Vacío) when used on it. */
public class NucleoVacioItem extends Item {
    public NucleoVacioItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().isClientSide()) return InteractionResult.SUCCESS;
        if (PortalHandler.tryActivate(ctx.getLevel(), ctx.getClickedPos().relative(ctx.getClickedFace()))) {
            if (ctx.getPlayer() != null && !ctx.getPlayer().isCreative()) ctx.getItemInHand().shrink(1);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }
}

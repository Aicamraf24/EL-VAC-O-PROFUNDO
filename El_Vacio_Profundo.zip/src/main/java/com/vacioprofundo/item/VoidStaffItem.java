package com.vacioprofundo.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Void Staff: fires a piercing beam (range 20) that damages every living target on its path. */
public class VoidStaffItem extends Item {
    public VoidStaffItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(stack)) return InteractionResult.FAIL;
        if (level instanceof ServerLevel sl) {
            Vec3 start = player.getEyePosition();
            Vec3 dir = player.getLookAngle();
            java.util.Set<LivingEntity> hit = new java.util.HashSet<>();
            for (double d = 1.0; d <= 20.0; d += 0.75) {
                Vec3 p = start.add(dir.scale(d));
                if (!level.getBlockState(net.minecraft.core.BlockPos.containing(p)).getCollisionShape(level, net.minecraft.core.BlockPos.containing(p)).isEmpty()) break;
                sl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.0);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(0.7), t -> t != player && t.isAlive())) hit.add(e);
            }
            for (LivingEntity e : hit) e.hurtServer(sl, sl.damageSources().indirectMagic(player, player), 9.0f);
            stack.hurtAndBreak(1, player, EquipmentSlot.MAINHAND);
        }
        player.getCooldowns().addCooldown(stack, 30);
        return InteractionResult.SUCCESS;
    }
}

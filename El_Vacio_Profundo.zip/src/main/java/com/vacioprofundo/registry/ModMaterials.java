package com.vacioprofundo.registry;

import com.vacioprofundo.VacioProfundo;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModMaterials {
    private ModMaterials() {}
    static TagKey<Item> itemTag(String n) { return TagKey.create(Registries.ITEM, VacioProfundo.id(n)); }
    // Progression: CRISTAL (iron+) < ASTRAL (diamond+) < OBSIDIANA (netherite) < VACIO (post-boss)
    public static final ToolMaterial CRISTAL = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 650, 7.0f, 2.5f, 15, itemTag("repairs_cristal"));
    public static final ToolMaterial ASTRAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1800, 8.5f, 3.5f, 12, itemTag("repairs_astral"));
    public static final ToolMaterial OBSIDIANA = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2400, 9.0f, 4.0f, 15, itemTag("repairs_obsidiana"));
    public static final ToolMaterial VACIO = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 3200, 10.0f, 5.0f, 20, itemTag("repairs_vacio"));
    public static final ArmorMaterial ARMOR_CRISTAL_ABISAL = new ArmorMaterial(24,
        Map.of(ArmorType.HELMET, 2, ArmorType.CHESTPLATE, 6, ArmorType.LEGGINGS, 5, ArmorType.BOOTS, 2, ArmorType.BODY, 6),
        12, SoundEvents.ARMOR_EQUIP_DIAMOND, 0.5f, 0.0f, itemTag("repairs_cristal_abisal"),
        ResourceKey.create(EquipmentAssets.ROOT_ID, VacioProfundo.id("cristal_abisal")));
    public static final ArmorMaterial ARMOR_PIEDRA_ASTRAL = new ArmorMaterial(33,
        Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 8, ArmorType.LEGGINGS, 6, ArmorType.BOOTS, 3, ArmorType.BODY, 8),
        12, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0f, 0.0f, itemTag("repairs_piedra_astral"),
        ResourceKey.create(EquipmentAssets.ROOT_ID, VacioProfundo.id("piedra_astral")));
    public static final ArmorMaterial ARMOR_OBSIDIANA_VIVIENTE = new ArmorMaterial(40,
        Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 8, ArmorType.LEGGINGS, 6, ArmorType.BOOTS, 3, ArmorType.BODY, 8),
        15, SoundEvents.ARMOR_EQUIP_DIAMOND, 3.0f, 0.1f, itemTag("repairs_obsidiana_viviente"),
        ResourceKey.create(EquipmentAssets.ROOT_ID, VacioProfundo.id("obsidiana_viviente")));
    public static final ArmorMaterial ARMOR_CAZADOR = new ArmorMaterial(20,
        Map.of(ArmorType.HELMET, 2, ArmorType.CHESTPLATE, 5, ArmorType.LEGGINGS, 4, ArmorType.BOOTS, 2, ArmorType.BODY, 5),
        14, SoundEvents.ARMOR_EQUIP_DIAMOND, 0.0f, 0.0f, itemTag("repairs_cazador"),
        ResourceKey.create(EquipmentAssets.ROOT_ID, VacioProfundo.id("cazador")));
    public static final ArmorMaterial ARMOR_VACIO = new ArmorMaterial(48,
        Map.of(ArmorType.HELMET, 4, ArmorType.CHESTPLATE, 9, ArmorType.LEGGINGS, 7, ArmorType.BOOTS, 4, ArmorType.BODY, 9),
        20, SoundEvents.ARMOR_EQUIP_DIAMOND, 4.0f, 0.1f, itemTag("repairs_vacio_set"),
        ResourceKey.create(EquipmentAssets.ROOT_ID, VacioProfundo.id("vacio")));
}

package com.vacioprofundo.registry;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.block.VacioPlantBlock;
import com.vacioprofundo.block.AbyssSaplingBlock;
import com.vacioprofundo.block.MiniHongoBlock;
import com.vacioprofundo.block.VacioPortalBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** AUTO-GENERATED block registry. All ids live in the "vacio_profundo" namespace. */
public final class ModBlocks {
    private ModBlocks() {}
    public static BlockBehaviour.Properties props(String name) {
        return BlockBehaviour.Properties.of().setId(ResourceKey.create(Registries.BLOCK, VacioProfundo.id(name)));
    }
    static Block register(String name, Block block, boolean withItem) {
        Registry.register(BuiltInRegistries.BLOCK, VacioProfundo.id(name), block);
        if (withItem) {
            Registry.register(BuiltInRegistries.ITEM, VacioProfundo.id(name), new BlockItem(block,
                new Item.Properties().setId(ResourceKey.create(Registries.ITEM, VacioProfundo.id(name))).useBlockDescriptionPrefix()));
        }
        return block;
    }
    static Block simple(String name, float hardness, float resistance, int light, SoundType sound) {
        BlockBehaviour.Properties p = props(name).strength(hardness, resistance).sound(sound);
        if (hardness >= 1.5f) p = p.requiresCorrectToolForDrops();
        if (light > 0) { final int l = light; p = p.lightLevel(s -> l); }
        return register(name, new Block(p), true);
    }
    // ---- wood helpers (vanilla block classes, oak sounds/behaviour) ----
    static BlockBehaviour.Properties woodProps(String n, float hard) { return props(n).strength(hard, hard).sound(SoundType.WOOD); }
    static Block log(String n) { return register(n, new RotatedPillarBlock(woodProps(n, 2f)), true); }
    static Block wood(String n) { return register(n, new Block(woodProps(n, 2f)), true); }
    static Block stairs(String n, Block base) { return register(n, new StairBlock(base.defaultBlockState(), woodProps(n, 2f)), true); }
    static Block slab(String n) { return register(n, new SlabBlock(woodProps(n, 2f)), true); }
    static Block fence(String n) { return register(n, new FenceBlock(woodProps(n, 2f)), true); }
    static Block gate(String n) { return register(n, new FenceGateBlock(WoodType.OAK, woodProps(n, 2f)), true); }
    static Block door(String n) {
        Block b = Registry.register(BuiltInRegistries.BLOCK, VacioProfundo.id(n), new DoorBlock(BlockSetType.OAK, woodProps(n, 3f).noOcclusion()));
        Registry.register(BuiltInRegistries.ITEM, VacioProfundo.id(n), new DoubleHighBlockItem(b,
            new Item.Properties().setId(ResourceKey.create(Registries.ITEM, VacioProfundo.id(n))).useBlockDescriptionPrefix()));
        return b;
    }
    static Block trapdoor(String n) { return register(n, new TrapDoorBlock(BlockSetType.OAK, woodProps(n, 3f).noOcclusion()), true); }
    static Block button(String n) { return register(n, new ButtonBlock(BlockSetType.OAK, 30, woodProps(n, 0.5f).noCollision()), true); }
    static Block plate(String n) { return register(n, new PressurePlateBlock(BlockSetType.OAK, woodProps(n, 0.5f).noCollision()), true); }
    static Block plant(String name, int light) {
        final int l = light;
        return register(name, new VacioPlantBlock(props(name).noCollision().instabreak().noOcclusion().sound(SoundType.GRASS).lightLevel(s -> l)), true);
    }
    public static final Block PIEDRA_PROFUNDA = simple("piedra_profunda", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block ADOQUIN_PROFUNDO = simple("adoquin_profundo", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA = simple("ladrillo_ruina", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA_AGRIETADO = simple("ladrillo_ruina_agrietado", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA_MUSGOSO = simple("ladrillo_ruina_musgoso", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block BALDOSA_ANTIGUA = simple("baldosa_antigua", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block PIEDRA_CRISTAL_OSCURO = simple("piedra_cristal_oscuro", 3.5f, 7.0f, 2, SoundType.STONE);
    public static final Block OBSIDIANA_VOLCANICA = simple("obsidiana_volcanica", 8.0f, 16.0f, 4, SoundType.STONE);
    public static final Block ROCA_MAGMA = simple("roca_magma", 3.0f, 6.0f, 6, SoundType.STONE);
    public static final Block TIERRA_PROFUNDA = simple("tierra_profunda", 0.6f, 3f, 0, SoundType.STONE);
    public static final Block LODO_ABISAL = simple("lodo_abisal", 0.6f, 3f, 0, SoundType.STONE);
    public static final Block HIERBA_PROFUNDA = simple("hierba_profunda", 0.6f, 0.6f, 0, SoundType.GRASS);
    public static final Block SOMBRERO_HONGO_CIAN = simple("sombrero_hongo_cian", 0.5f, 0.5f, 12, SoundType.FUNGUS);
    public static final Block SOMBRERO_HONGO_VIOLETA = simple("sombrero_hongo_violeta", 0.5f, 0.5f, 10, SoundType.FUNGUS);
    public static final Block SOMBRERO_HONGO_AMBAR = simple("sombrero_hongo_ambar", 0.5f, 0.5f, 10, SoundType.FUNGUS);
    public static final Block CRISTAL_LUMINOSO_CIAN = simple("cristal_luminoso_cian", 2.0f, 3f, 14, SoundType.AMETHYST);
    public static final Block CRISTAL_LUMINOSO_VIOLETA = simple("cristal_luminoso_violeta", 2.0f, 3f, 14, SoundType.AMETHYST);
    public static final Block CRISTAL_LUMINOSO_AMBAR = simple("cristal_luminoso_ambar", 2.0f, 3f, 13, SoundType.AMETHYST);
    public static final Block CRISTAL_OSCURO_VIOLETA = simple("cristal_oscuro_violeta", 2.0f, 3f, 5, SoundType.AMETHYST);
    public static final Block MINERAL_CRISTAL_ABISAL = simple("mineral_cristal_abisal", 3.5f, 6.5f, 6, SoundType.STONE);
    public static final Block MINERAL_VACIO = simple("mineral_vacio", 5.0f, 8.0f, 3, SoundType.STONE);
    public static final Block MINERAL_ESENCIA_OSCURA = simple("mineral_esencia_oscura", 4.0f, 7.0f, 4, SoundType.STONE);
    public static final Block MINERAL_PIEDRA_ASTRAL = simple("mineral_piedra_astral", 4.5f, 7.5f, 2, SoundType.STONE);
    public static final Block MINERAL_CUARZO_PROFUNDO = simple("mineral_cuarzo_profundo", 3.0f, 6.0f, 3, SoundType.STONE);
    public static final Block MINERAL_SANGRE = simple("mineral_sangre", 5.0f, 8.0f, 5, SoundType.STONE);
    public static final Block MINERAL_FRAGMENTO_DIMENSIONAL = simple("mineral_fragmento_dimensional", 8.0f, 11.0f, 9, SoundType.STONE);
    public static final Block MINERAL_OBSIDIANA_VIVIENTE = simple("mineral_obsidiana_viviente", 10.0f, 13.0f, 7, SoundType.STONE);
    public static final Block BLOQUE_CRISTAL_ABISAL = simple("bloque_cristal_abisal", 5.0f, 6f, 4, SoundType.METAL);
    public static final Block BLOQUE_VACIO = simple("bloque_vacio", 5.0f, 6f, 0, SoundType.METAL);
    public static final Block BLOQUE_PIEDRA_ASTRAL = simple("bloque_piedra_astral", 5.0f, 6f, 0, SoundType.METAL);
    public static final Block BLOQUE_OBSIDIANA_VIVIENTE = simple("bloque_obsidiana_viviente", 5.0f, 6f, 3, SoundType.METAL);
    public static final Block FLOR_LUMINOSA = plant("flor_luminosa", 9);
    public static final Block HONGO_BRILLANTE = plant("hongo_brillante", 8);
    public static final Block HELECHO_ABISAL = plant("helecho_abisal", 4);
    public static final Block HIERBA_LUZ = plant("hierba_luz", 5);
    public static final Block RACIMO_CRISTAL_CIAN = plant("racimo_cristal_cian", 10);
    public static final Block RACIMO_CRISTAL_VIOLETA = plant("racimo_cristal_violeta", 10);
    public static final Block RACIMO_CRISTAL_AMBAR = plant("racimo_cristal_ambar", 9);
    public static final Block BULBO_PANTANO = plant("bulbo_pantano", 7);
    public static final Block BROTE_ABISAL = register("brote_abisal", new AbyssSaplingBlock(props("brote_abisal").noCollision().instabreak().noOcclusion().randomTicks().sound(SoundType.GRASS).lightLevel(s -> 6)), true);
    public static final Block MARCO_VACIO = simple("marco_vacio", 50.0f, 1200f, 8, SoundType.STONE);
    public static final Block PORTAL_VACIO = register("portal_vacio", new VacioPortalBlock(props("portal_vacio").noCollision().instabreak().lightLevel(s->11).noLootTable().noOcclusion()), false);
    public static final Block MADERA_HONGO = log("madera_hongo");
    public static final Block TABLONES_HONGO = wood("tablones_hongo");
    public static final Block ESCALERA_HONGO = stairs("escalera_hongo", TABLONES_HONGO);
    public static final Block LOSA_HONGO = slab("losa_hongo");
    public static final Block VALLA_HONGO = fence("valla_hongo");
    public static final Block PUERTA_VALLA_HONGO = gate("puerta_valla_hongo");
    public static final Block PUERTA_HONGO = door("puerta_hongo");
    public static final Block TRAMPILLA_HONGO = trapdoor("trampilla_hongo");
    public static final Block BOTON_HONGO = button("boton_hongo");
    public static final Block PLACA_PRESION_HONGO = plate("placa_presion_hongo");
    public static final Block RAIZ_ABISAL = log("raiz_abisal");
    public static final Block TABLONES_RAIZ_ABISAL = wood("tablones_raiz_abisal");
    public static final Block ESCALERA_RAIZ_ABISAL = stairs("escalera_raiz_abisal", TABLONES_RAIZ_ABISAL);
    public static final Block LOSA_RAIZ_ABISAL = slab("losa_raiz_abisal");
    public static final Block VALLA_RAIZ_ABISAL = fence("valla_raiz_abisal");
    public static final Block PUERTA_VALLA_RAIZ_ABISAL = gate("puerta_valla_raiz_abisal");
    public static final Block PUERTA_RAIZ_ABISAL = door("puerta_raiz_abisal");
    public static final Block TRAMPILLA_RAIZ_ABISAL = trapdoor("trampilla_raiz_abisal");
    public static final Block BOTON_RAIZ_ABISAL = button("boton_raiz_abisal");
    public static final Block PLACA_PRESION_RAIZ_ABISAL = plate("placa_presion_raiz_abisal");
    public static final Block FOLLAJE_ABISAL = simple("follaje_abisal", 0.3f, 0.3f, 9, SoundType.GRASS);
    public static final Block MINI_HONGO_CIAN = register("mini_hongo_cian", new MiniHongoBlock(props("mini_hongo_cian").noCollision().instabreak().noOcclusion().randomTicks().sound(SoundType.FUNGUS).lightLevel(s -> 7)), true);
    public static final Block MINI_HONGO_VIOLETA = register("mini_hongo_violeta", new MiniHongoBlock(props("mini_hongo_violeta").noCollision().instabreak().noOcclusion().randomTicks().sound(SoundType.FUNGUS).lightLevel(s -> 7)), true);
    public static final Block MINI_HONGO_AMBAR = register("mini_hongo_ambar", new MiniHongoBlock(props("mini_hongo_ambar").noCollision().instabreak().noOcclusion().randomTicks().sound(SoundType.FUNGUS).lightLevel(s -> 7)), true);
    public static void init() {}
}

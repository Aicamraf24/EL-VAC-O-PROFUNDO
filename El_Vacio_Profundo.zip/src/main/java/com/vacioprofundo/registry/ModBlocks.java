package com.vacioprofundo.registry;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.block.VacioPlantBlock;
import com.vacioprofundo.block.VacioPortalBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** AUTO-GENERATED block registry. All ids live in the "vacio_profundo" namespace. */
public final class ModBlocks {
    private ModBlocks() {}
    public static BlockBehaviour.Properties props(String name) {
        return BlockBehaviour.Properties.of().setId(ResourceKey.create(Registries.BLOCK, VacioProfundo.id(name)));
    }
    static Block register(String name, Block block, boolean withItem) {
        Registry.register(BuiltInRegistries.BLOCK, VacioProfundo.id(name), block);
        if (withItem) {
            Registry.register(BuiltInRegistries.ITEM, VacioProfundo.id(name), new BlockItem(block,
                new Item.Properties().setId(ResourceKey.create(Registries.ITEM, VacioProfundo.id(name))).useBlockDescriptionPrefix()));
        }
        return block;
    }
    static Block simple(String name, float hardness, float resistance, int light, SoundType sound) {
        BlockBehaviour.Properties p = props(name).strength(hardness, resistance).sound(sound);
        if (hardness >= 1.5f) p = p.requiresCorrectToolForDrops();
        if (light > 0) { final int l = light; p = p.lightLevel(s -> l); }
        return register(name, new Block(p), true);
    }
    static Block plant(String name, int light) {
        final int l = light;
        return register(name, new VacioPlantBlock(props(name).noCollision().instabreak().noOcclusion().sound(SoundType.GRASS).lightLevel(s -> l)), true);
    }
    public static final Block PIEDRA_PROFUNDA = simple("piedra_profunda", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block ADOQUIN_PROFUNDO = simple("adoquin_profundo", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA = simple("ladrillo_ruina", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA_AGRIETADO = simple("ladrillo_ruina_agrietado", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block LADRILLO_RUINA_MUSGOSO = simple("ladrillo_ruina_musgoso", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block BALDOSA_ANTIGUA = simple("baldosa_antigua", 3.0f, 6.0f, 0, SoundType.STONE);
    public static final Block PIEDRA_CRISTAL_OSCURO = simple("piedra_cristal_oscuro", 3.5f, 7.0f, 2, SoundType.STONE);
    public static final Block OBSIDIANA_VOLCANICA = simple("obsidiana_volcanica", 8.0f, 16.0f, 4, SoundType.STONE);
    public static final Block ROCA_MAGMA = simple("roca_magma", 3.0f, 6.0f, 6, SoundType.STONE);
    public static final Block TIERRA_PROFUNDA = simple("tierra_profunda", 0.6f, 3f, 0, SoundType.STONE);
    public static final Block LODO_ABISAL = simple("lodo_abisal", 0.6f, 3f, 0, SoundType.STONE);
    public static final Block MADERA_HONGO = simple("madera_hongo", 1.0f, 3f, 0, SoundType.STONE);
    public static final Block RAIZ_ABISAL = simple("raiz_abisal", 1.5f, 3.0f, 0, SoundType.STONE);
    public static final Block HIERBA_PROFUNDA = simple("hierba_profunda", 0.6f, 0.6f, 0, SoundType.GRASS);
    public static final Block SOMBRERO_HONGO_CIAN = simple("sombrero_hongo_cian", 0.5f, 0.5f, 12, SoundType.FUNGUS);
    public static final Block SOMBRERO_HONGO_VIOLETA = simple("sombrero_hongo_violeta", 0.5f, 0.5f, 10, SoundType.FUNGUS);
    public static final Block SOMBRERO_HONGO_AMBAR = simple("sombrero_hongo_ambar", 0.5f, 0.5f, 10, SoundType.FUNGUS);
    public static final Block CRISTAL_LUMINOSO_CIAN = simple("cristal_luminoso_cian", 2.0f, 3f, 14, SoundType.AMETHYST);
    public static final Block CRISTAL_LUMINOSO_VIOLETA = simple("cristal_luminoso_violeta", 2.0f, 3f, 14, SoundType.AMETHYST);
    public static final Block CRISTAL_LUMINOSO_AMBAR = simple("cristal_luminoso_ambar", 2.0f, 3f, 13, SoundType.AMETHYST);
    public static final Block CRISTAL_OSCURO_VIOLETA = simple("cristal_oscuro_violeta", 2.0f, 3f, 5, SoundType.AMETHYST);
    public static final Block MINERAL_CRISTAL_ABISAL = simple("mineral_cristal_abisal", 3.5f, 6.5f, 6, SoundType.STONE);
    public static final Block MINERAL_VACIO = simple("mineral_vacio", 5.0f, 8.0f, 3, SoundType.STONE);
    public static final Block MINERAL_ESENCIA_OSCURA = simple("mineral_esencia_oscura", 4.0f, 7.0f, 4, SoundType.STONE);
    public static final Block MINERAL_PIEDRA_ASTRAL = simple("mineral_piedra_astral", 4.5f, 7.5f, 2, SoundType.STONE);
    public static final Block MINERAL_CUARZO_PROFUNDO = simple("mineral_cuarzo_profundo", 3.0f, 6.0f, 3, SoundType.STONE);
    public static final Block MINERAL_SANGRE = simple("mineral_sangre", 5.0f, 8.0f, 5, SoundType.STONE);
    public static final Block MINERAL_FRAGMENTO_DIMENSIONAL = simple("mineral_fragmento_dimensional", 8.0f, 11.0f, 9, SoundType.STONE);
    public static final Block MINERAL_OBSIDIANA_VIVIENTE = simple("mineral_obsidiana_viviente", 10.0f, 13.0f, 7, SoundType.STONE);
    public static final Block BLOQUE_CRISTAL_ABISAL = simple("bloque_cristal_abisal", 5.0f, 6f, 4, SoundType.METAL);
    public static final Block BLOQUE_VACIO = simple("bloque_vacio", 5.0f, 6f, 0, SoundType.METAL);
    public static final Block BLOQUE_PIEDRA_ASTRAL = simple("bloque_piedra_astral", 5.0f, 6f, 0, SoundType.METAL);
    public static final Block BLOQUE_OBSIDIANA_VIVIENTE = simple("bloque_obsidiana_viviente", 5.0f, 6f, 3, SoundType.METAL);
    public static final Block FLOR_LUMINOSA = plant("flor_luminosa", 9);
    public static final Block HONGO_BRILLANTE = plant("hongo_brillante", 8);
    public static final Block HELECHO_ABISAL = plant("helecho_abisal", 4);
    public static final Block HIERBA_LUZ = plant("hierba_luz", 5);
    public static final Block RACIMO_CRISTAL_CIAN = plant("racimo_cristal_cian", 10);
    public static final Block RACIMO_CRISTAL_VIOLETA = plant("racimo_cristal_violeta", 10);
    public static final Block RACIMO_CRISTAL_AMBAR = plant("racimo_cristal_ambar", 9);
    public static final Block BULBO_PANTANO = plant("bulbo_pantano", 7);
    public static final Block MARCO_VACIO = simple("marco_vacio", 50.0f, 1200f, 8, SoundType.STONE);
    public static final Block PORTAL_VACIO = register("portal_vacio", new VacioPortalBlock(props("portal_vacio").noCollision().instabreak().lightLevel(s->11).noLootTable().noOcclusion()), false);
    public static void init() {}
}

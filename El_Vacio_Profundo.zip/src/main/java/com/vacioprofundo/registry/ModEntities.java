package com.vacioprofundo.registry;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.entity.RevAbismo;
import com.vacioprofundo.entity.species.AcechadorAbisal;
import com.vacioprofundo.entity.species.AranaCristalina;
import com.vacioprofundo.entity.species.GusanoProfundidades;
import com.vacioprofundo.entity.species.MurcielagoGigante;
import com.vacioprofundo.entity.species.GolemObsidiana;
import com.vacioprofundo.entity.species.CiempiesColosal;
import com.vacioprofundo.entity.species.SanguijuelaAbisal;
import com.vacioprofundo.entity.species.DevoradorHongos;
import com.vacioprofundo.entity.species.EspectroCristal;
import com.vacioprofundo.entity.species.CangrejoCavernas;
import com.vacioprofundo.entity.species.ReptadorSombras;
import com.vacioprofundo.entity.species.ColosoSubterraneo;
import com.vacioprofundo.entity.species.SerpienteAbisal;
import com.vacioprofundo.entity.species.DevoradorAlmas;
import com.vacioprofundo.entity.species.GuardianRuinas;
import com.vacioprofundo.entity.species.BestiaMagma;
import com.vacioprofundo.entity.species.CazadorInvisible;
import com.vacioprofundo.entity.species.HidraCristal;
import com.vacioprofundo.entity.species.LeviatanSubterraneo;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** AUTO-GENERATED entity registry (20 species incl. boss). */
public final class ModEntities {
    private ModEntities() {}
    public static final Map<String, EntityType<?>> TYPES = new LinkedHashMap<>();
    static <T extends Entity> EntityType<T> reg(String id, EntityType.EntityFactory<T> factory, MobCategory cat, float w, float h) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, VacioProfundo.id(id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, EntityType.Builder.of(factory, cat).sized(w, h).clientTrackingRange(10).build(key));
    }
    public static final EntityType<AcechadorAbisal> ACECHADOR_ABISAL = reg("acechador_abisal", AcechadorAbisal::new, MobCategory.MONSTER, 0.6f, 2.44f);
    public static final EntityType<AranaCristalina> ARANA_CRISTALINA = reg("arana_cristalina", AranaCristalina::new, MobCategory.MONSTER, 1.3f, 1.56f);
    public static final EntityType<GusanoProfundidades> GUSANO_PROFUNDIDADES = reg("gusano_profundidades", GusanoProfundidades::new, MobCategory.MONSTER, 1.0f, 1.00f);
    public static final EntityType<MurcielagoGigante> MURCIELAGO_GIGANTE = reg("murcielago_gigante", MurcielagoGigante::new, MobCategory.MONSTER, 1.0f, 1.69f);
    public static final EntityType<GolemObsidiana> GOLEM_OBSIDIANA = reg("golem_obsidiana", GolemObsidiana::new, MobCategory.MONSTER, 1.3f, 2.00f);
    public static final EntityType<CiempiesColosal> CIEMPIES_COLOSAL = reg("ciempies_colosal", CiempiesColosal::new, MobCategory.MONSTER, 1.2f, 0.62f);
    public static final EntityType<SanguijuelaAbisal> SANGUIJUELA_ABISAL = reg("sanguijuela_abisal", SanguijuelaAbisal::new, MobCategory.WATER_CREATURE, 0.6f, 1.00f);
    public static final EntityType<DevoradorHongos> DEVORADOR_HONGOS = reg("devorador_hongos", DevoradorHongos::new, MobCategory.MONSTER, 1.2f, 1.44f);
    public static final EntityType<EspectroCristal> ESPECTRO_CRISTAL = reg("espectro_cristal", EspectroCristal::new, MobCategory.MONSTER, 0.9f, 2.00f);
    public static final EntityType<CangrejoCavernas> CANGREJO_CAVERNAS = reg("cangrejo_cavernas", CangrejoCavernas::new, MobCategory.MONSTER, 1.2f, 0.88f);
    public static final EntityType<ReptadorSombras> REPTADOR_SOMBRAS = reg("reptador_sombras", ReptadorSombras::new, MobCategory.MONSTER, 1.0f, 0.69f);
    public static final EntityType<ColosoSubterraneo> COLOSO_SUBTERRANEO = reg("coloso_subterraneo", ColosoSubterraneo::new, MobCategory.MONSTER, 2.6f, 2.88f);
    public static final EntityType<SerpienteAbisal> SERPIENTE_ABISAL = reg("serpiente_abisal", SerpienteAbisal::new, MobCategory.WATER_CREATURE, 0.9f, 1.00f);
    public static final EntityType<DevoradorAlmas> DEVORADOR_ALMAS = reg("devorador_almas", DevoradorAlmas::new, MobCategory.MONSTER, 1.1f, 2.38f);
    public static final EntityType<GuardianRuinas> GUARDIAN_RUINAS = reg("guardian_ruinas", GuardianRuinas::new, MobCategory.MONSTER, 1.0f, 2.38f);
    public static final EntityType<BestiaMagma> BESTIA_MAGMA = reg("bestia_magma", BestiaMagma::new, MobCategory.MONSTER, 1.6f, 1.50f);
    public static final EntityType<CazadorInvisible> CAZADOR_INVISIBLE = reg("cazador_invisible", CazadorInvisible::new, MobCategory.MONSTER, 0.7f, 1.94f);
    public static final EntityType<HidraCristal> HIDRA_CRISTAL = reg("hidra_cristal", HidraCristal::new, MobCategory.MONSTER, 2.0f, 1.88f);
    public static final EntityType<LeviatanSubterraneo> LEVIATAN_SUBTERRANEO = reg("leviatan_subterraneo", LeviatanSubterraneo::new, MobCategory.WATER_CREATURE, 3.2f, 2.38f);
    public static final EntityType<RevAbismo> REY_ABISMO = reg("rey_abismo", RevAbismo::new, MobCategory.MONSTER, 2.0f, 3.56f);
    public static void init() {
        TYPES.put("acechador_abisal", ACECHADOR_ABISAL);
        TYPES.put("arana_cristalina", ARANA_CRISTALINA);
        TYPES.put("gusano_profundidades", GUSANO_PROFUNDIDADES);
        TYPES.put("murcielago_gigante", MURCIELAGO_GIGANTE);
        TYPES.put("golem_obsidiana", GOLEM_OBSIDIANA);
        TYPES.put("ciempies_colosal", CIEMPIES_COLOSAL);
        TYPES.put("sanguijuela_abisal", SANGUIJUELA_ABISAL);
        TYPES.put("devorador_hongos", DEVORADOR_HONGOS);
        TYPES.put("espectro_cristal", ESPECTRO_CRISTAL);
        TYPES.put("cangrejo_cavernas", CANGREJO_CAVERNAS);
        TYPES.put("reptador_sombras", REPTADOR_SOMBRAS);
        TYPES.put("coloso_subterraneo", COLOSO_SUBTERRANEO);
        TYPES.put("serpiente_abisal", SERPIENTE_ABISAL);
        TYPES.put("devorador_almas", DEVORADOR_ALMAS);
        TYPES.put("guardian_ruinas", GUARDIAN_RUINAS);
        TYPES.put("bestia_magma", BESTIA_MAGMA);
        TYPES.put("cazador_invisible", CAZADOR_INVISIBLE);
        TYPES.put("hidra_cristal", HIDRA_CRISTAL);
        TYPES.put("leviatan_subterraneo", LEVIATAN_SUBTERRANEO);
        TYPES.put("rey_abismo", REY_ABISMO);
        FabricDefaultAttributeRegistry.register(ACECHADOR_ABISAL, AcechadorAbisal.attributes());
        FabricDefaultAttributeRegistry.register(ARANA_CRISTALINA, AranaCristalina.attributes());
        FabricDefaultAttributeRegistry.register(GUSANO_PROFUNDIDADES, GusanoProfundidades.attributes());
        FabricDefaultAttributeRegistry.register(MURCIELAGO_GIGANTE, MurcielagoGigante.attributes());
        FabricDefaultAttributeRegistry.register(GOLEM_OBSIDIANA, GolemObsidiana.attributes());
        FabricDefaultAttributeRegistry.register(CIEMPIES_COLOSAL, CiempiesColosal.attributes());
        FabricDefaultAttributeRegistry.register(SANGUIJUELA_ABISAL, SanguijuelaAbisal.attributes());
        FabricDefaultAttributeRegistry.register(DEVORADOR_HONGOS, DevoradorHongos.attributes());
        FabricDefaultAttributeRegistry.register(ESPECTRO_CRISTAL, EspectroCristal.attributes());
        FabricDefaultAttributeRegistry.register(CANGREJO_CAVERNAS, CangrejoCavernas.attributes());
        FabricDefaultAttributeRegistry.register(REPTADOR_SOMBRAS, ReptadorSombras.attributes());
        FabricDefaultAttributeRegistry.register(COLOSO_SUBTERRANEO, ColosoSubterraneo.attributes());
        FabricDefaultAttributeRegistry.register(SERPIENTE_ABISAL, SerpienteAbisal.attributes());
        FabricDefaultAttributeRegistry.register(DEVORADOR_ALMAS, DevoradorAlmas.attributes());
        FabricDefaultAttributeRegistry.register(GUARDIAN_RUINAS, GuardianRuinas.attributes());
        FabricDefaultAttributeRegistry.register(BESTIA_MAGMA, BestiaMagma.attributes());
        FabricDefaultAttributeRegistry.register(CAZADOR_INVISIBLE, CazadorInvisible.attributes());
        FabricDefaultAttributeRegistry.register(HIDRA_CRISTAL, HidraCristal.attributes());
        FabricDefaultAttributeRegistry.register(LEVIATAN_SUBTERRANEO, LeviatanSubterraneo.attributes());
        FabricDefaultAttributeRegistry.register(REY_ABISMO, RevAbismo.attributes());
    }
}

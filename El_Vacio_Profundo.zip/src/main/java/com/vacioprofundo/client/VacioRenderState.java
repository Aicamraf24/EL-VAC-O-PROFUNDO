package com.vacioprofundo.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class VacioRenderState extends LivingEntityRenderState {
    public float special, attackAnim;
    public boolean aggressive, resting;
    public int phase;
}

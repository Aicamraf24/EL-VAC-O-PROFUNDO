package com.vacioprofundo.client;

/** AUTO-GENERATED: anatomy of every creature (pivot, rotation, boxes with UV offsets). */
public final class ModelSpecs {
    private ModelSpecs() {}
    public record PartSpec(String name, float px, float py, float pz, float rx, float ry, float rz, float[][] boxes) {}
    static PartSpec[] acechador_abisal(){ return new PartSpec[]{
            new PartSpec("body",0f,8f,0f,0f,0f,0f,new float[][]{{40.0f,0.0f,-3.0f,-14.0f,-1.5f,6.0f,14.0f,3.0f},{24.0f,20.0f,-1.0f,-12.0f,-2.0f,2.0f,5.0f,1.0f}}),
            new PartSpec("head",0f,-6f,0f,0f,0f,0f,new float[][]{{0.0f,20.0f,-3.0f,-6.0f,-3.0f,6.0f,6.0f,6.0f},{30.0f,20.0f,-3.5f,-9.0f,-1.0f,1.0f,4.0f,1.0f},{34.0f,20.0f,2.5f,-9.0f,-1.0f,1.0f,4.0f,1.0f}}),
            new PartSpec("arm0",-4.0f,-4f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-1.0f,-2.0f,-1.0f,2.0f,18.0f,2.0f}}),
            new PartSpec("arm1",4.0f,-4f,0f,0f,0f,0f,new float[][]{{8.0f,0.0f,-1.0f,-2.0f,-1.0f,2.0f,18.0f,2.0f}}),
            new PartSpec("leg0",-1.7999999999999998f,8f,0f,0f,0f,0f,new float[][]{{16.0f,0.0f,-1.5f,0.0f,-1.5f,3.0f,16.0f,3.0f}}),
            new PartSpec("leg1",1.7999999999999998f,8f,0f,0f,0f,0f,new float[][]{{28.0f,0.0f,-1.5f,0.0f,-1.5f,3.0f,16.0f,3.0f}})}; }
    static final int TEX_ACECHADOR_ABISAL=64;
    static PartSpec[] arana_cristalina(){ return new PartSpec[]{
            new PartSpec("body",0f,14f,0f,0f,0f,0f,new float[][]{{46.0f,0.0f,-4.5f,-6.0f,-5.0f,9.0f,6.0f,10.0f}}),
            new PartSpec("head",0f,13f,-5.0f,0f,0f,0f,new float[][]{{84.0f,0.0f,-3.5f,-6.0f,-7.0f,7.0f,7.0f,7.0f}}),
            new PartSpec("abdomen",0f,14f,4.0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-5.5f,-8.0f,0.0f,11.0f,8.0f,12.0f},{0.0f,20.0f,-4.7f,-13.0f,2.0f,3.0f,6.0f,3.0f},{112.0f,0.0f,-1.5f,-15.0f,5.0f,3.0f,8.0f,3.0f},{12.0f,20.0f,1.7000000000000002f,-13.0f,8.0f,3.0f,6.0f,3.0f}}),
            new PartSpec("sleg0",-4.5f,14f,-3.0f,0f,0.5249999999999999f,0.55f,new float[][]{{24.0f,20.0f,-14.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg1",4.5f,14f,-3.0f,0f,-0.5249999999999999f,-0.55f,new float[][]{{56.0f,20.0f,0.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg2",-4.5f,14f,-0.6666666666666665f,0f,0.175f,0.55f,new float[][]{{88.0f,20.0f,-14.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg3",4.5f,14f,-0.6666666666666665f,0f,-0.175f,-0.55f,new float[][]{{0.0f,29.0f,0.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg4",-4.5f,14f,1.666666666666667f,0f,-0.175f,0.55f,new float[][]{{32.0f,29.0f,-14.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg5",4.5f,14f,1.666666666666667f,0f,0.175f,-0.55f,new float[][]{{64.0f,29.0f,0.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg6",-4.5f,14f,4.0f,0f,-0.5249999999999999f,0.55f,new float[][]{{96.0f,29.0f,-14.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}}),
            new PartSpec("sleg7",4.5f,14f,4.0f,0f,0.5249999999999999f,-0.55f,new float[][]{{0.0f,33.0f,0.0f,-1.0f,-1.0f,14.0f,2.0f,2.0f}})}; }
    static final int TEX_ARANA_CRISTALINA=128;
    static PartSpec[] gusano_profundidades(){ return new PartSpec[]{
            new PartSpec("seg0",0f,16f,-18f,0f,0f,0f,new float[][]{{0.0f,0.0f,-5.0f,-8.0f,0.0f,10.0f,8.0f,6.0f}}),
            new PartSpec("seg1",0f,16f,-12f,0f,0f,0f,new float[][]{{0.0f,14.0f,-4.5f,-7.0f,0.0f,9.0f,7.0f,6.0f}}),
            new PartSpec("seg2",0f,16f,-6f,0f,0f,0f,new float[][]{{30.0f,14.0f,-4.5f,-7.0f,0.0f,9.0f,7.0f,5.0f}}),
            new PartSpec("seg3",0f,16f,-1f,0f,0f,0f,new float[][]{{0.0f,27.0f,-4.0f,-6.0f,0.0f,8.0f,6.0f,5.0f}}),
            new PartSpec("seg4",0f,16f,4f,0f,0f,0f,new float[][]{{26.0f,27.0f,-3.5f,-6.0f,0.0f,7.0f,6.0f,4.0f}}),
            new PartSpec("seg5",0f,16f,8f,0f,0f,0f,new float[][]{{0.0f,38.0f,-3.0f,-5.0f,0.0f,6.0f,5.0f,4.0f}}),
            new PartSpec("seg6",0f,16f,12f,0f,0f,0f,new float[][]{{20.0f,38.0f,-3.0f,-5.0f,0.0f,6.0f,5.0f,3.0f}}),
            new PartSpec("head",0f,16f,-18f,0f,0f,0f,new float[][]{{32.0f,0.0f,-5.0f,-8.0f,-6.0f,10.0f,8.0f,6.0f},{28.0f,47.0f,-5.0f,-5.0f,-7.0f,10.0f,1.0f,1.0f}}),
            new PartSpec("jaw",0f,22f,-18f,0f,0f,0f,new float[][]{{0.0f,47.0f,-4.0f,-1.0f,-6.0f,8.0f,2.0f,6.0f}})}; }
    static final int TEX_GUSANO_PROFUNDIDADES=64;
    static PartSpec[] murcielago_gigante(){ return new PartSpec[]{
            new PartSpec("body",0f,10f,0f,0.4f,0f,0f,new float[][]{{0.0f,0.0f,-3.0f,-5.0f,-4.0f,6.0f,10.0f,6.0f}}),
            new PartSpec("head",0f,5f,-3f,0f,0f,0f,new float[][]{{24.0f,0.0f,-3.0f,-3.0f,-5.0f,6.0f,6.0f,5.0f},{52.0f,27.0f,-5.0f,-8.0f,-3.0f,2.0f,5.0f,1.0f},{58.0f,27.0f,3.0f,-8.0f,-3.0f,2.0f,5.0f,1.0f},{8.0f,38.0f,-2.0f,-1.0f,-5.5f,1.0f,1.0f,1.0f},{12.0f,38.0f,1.0f,-1.0f,-5.5f,1.0f,1.0f,1.0f}}),
            new PartSpec("wing0",-3f,6f,0f,0f,0f,0f,new float[][]{{0.0f,16.0f,-16.0f,0.0f,-3.0f,16.0f,1.0f,10.0f}}),
            new PartSpec("wing1",3f,6f,0f,0f,0f,0f,new float[][]{{0.0f,27.0f,0.0f,0.0f,-3.0f,16.0f,1.0f,10.0f}}),
            new PartSpec("leg0",-1.5f,16f,1f,0f,0f,0f,new float[][]{{0.0f,38.0f,-0.5f,0.0f,-0.5f,1.0f,4.0f,1.0f}}),
            new PartSpec("leg1",1.5f,16f,1f,0f,0f,0f,new float[][]{{4.0f,38.0f,-0.5f,0.0f,-0.5f,1.0f,4.0f,1.0f}})}; }
    static final int TEX_MURCIELAGO_GIGANTE=64;
    static PartSpec[] golem_obsidiana(){ return new PartSpec[]{
            new PartSpec("body",0f,14f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-6.0f,-14.0f,-4.0f,12.0f,14.0f,8.0f},{48.0f,22.0f,-8.0f,-16.0f,-2.0f,3.0f,5.0f,4.0f},{62.0f,22.0f,5.0f,-16.0f,-2.0f,3.0f,5.0f,4.0f},{76.0f,22.0f,-1.0f,-10.0f,-4.2f,2.0f,5.0f,1.0f}}),
            new PartSpec("head",0f,0f,0f,0f,0f,0f,new float[][]{{88.0f,0.0f,-4.0f,-8.0f,-4.0f,8.0f,8.0f,8.0f},{82.0f,22.0f,-2.0f,-5.0f,-4.5f,4.0f,1.0f,1.0f}}),
            new PartSpec("arm0",-9.0f,2f,0f,0f,0f,0f,new float[][]{{40.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,16.0f,6.0f}}),
            new PartSpec("arm1",9.0f,2f,0f,0f,0f,0f,new float[][]{{64.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,16.0f,6.0f}}),
            new PartSpec("leg0",-3.5999999999999996f,14f,0f,0f,0f,0f,new float[][]{{0.0f,22.0f,-3.0f,0.0f,-3.0f,6.0f,10.0f,6.0f}}),
            new PartSpec("leg1",3.5999999999999996f,14f,0f,0f,0f,0f,new float[][]{{24.0f,22.0f,-3.0f,0.0f,-3.0f,6.0f,10.0f,6.0f}})}; }
    static final int TEX_GOLEM_OBSIDIANA=128;
    static PartSpec[] ciempies_colosal(){ return new PartSpec[]{
            new PartSpec("seg0",0f,19f,-30f,0f,0f,0f,new float[][]{{0.0f,0.0f,-3.0f,-5.0f,0.0f,6.0f,5.0f,7.0f}}),
            new PartSpec("seg1",0f,19f,-23f,0f,0f,0f,new float[][]{{26.0f,0.0f,-3.0f,-5.0f,0.0f,6.0f,5.0f,7.0f}}),
            new PartSpec("seg2",0f,19f,-16f,0f,0f,0f,new float[][]{{52.0f,0.0f,-3.0f,-5.0f,0.0f,6.0f,5.0f,7.0f}}),
            new PartSpec("seg3",0f,19f,-9f,0f,0f,0f,new float[][]{{78.0f,0.0f,-2.5f,-5.0f,0.0f,5.0f,5.0f,6.0f}}),
            new PartSpec("seg4",0f,19f,-3f,0f,0f,0f,new float[][]{{0.0f,12.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,6.0f}}),
            new PartSpec("seg5",0f,19f,3f,0f,0f,0f,new float[][]{{22.0f,12.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,6.0f}}),
            new PartSpec("seg6",0f,19f,9f,0f,0f,0f,new float[][]{{44.0f,12.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,6.0f}}),
            new PartSpec("seg7",0f,19f,15f,0f,0f,0f,new float[][]{{66.0f,12.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,6.0f}}),
            new PartSpec("seg8",0f,19f,21f,0f,0f,0f,new float[][]{{88.0f,12.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,5.0f}}),
            new PartSpec("seg9",0f,19f,26f,0f,0f,0f,new float[][]{{108.0f,12.0f,-2.0f,-4.0f,0.0f,4.0f,4.0f,5.0f}}),
            new PartSpec("leg0",-3f,21f,-30.0f,0f,0f,0f,new float[][]{{28.0f,22.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg1",3f,21f,-30.0f,0f,0f,0f,new float[][]{{42.0f,22.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg2",-3f,21f,-23.5f,0f,0f,0f,new float[][]{{56.0f,22.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg3",3f,21f,-23.5f,0f,0f,0f,new float[][]{{70.0f,22.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg4",-3f,21f,-17.0f,0f,0f,0f,new float[][]{{84.0f,22.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg5",3f,21f,-17.0f,0f,0f,0f,new float[][]{{98.0f,22.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg6",-3f,21f,-10.5f,0f,0f,0f,new float[][]{{112.0f,22.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg7",3f,21f,-10.5f,0f,0f,0f,new float[][]{{0.0f,27.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg8",-3f,21f,-4.0f,0f,0f,0f,new float[][]{{14.0f,27.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg9",3f,21f,-4.0f,0f,0f,0f,new float[][]{{28.0f,27.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg10",-3f,21f,2.5f,0f,0f,0f,new float[][]{{42.0f,27.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg11",3f,21f,2.5f,0f,0f,0f,new float[][]{{56.0f,27.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg12",-3f,21f,9.0f,0f,0f,0f,new float[][]{{70.0f,27.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg13",3f,21f,9.0f,0f,0f,0f,new float[][]{{84.0f,27.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg14",-3f,21f,15.5f,0f,0f,0f,new float[][]{{98.0f,27.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg15",3f,21f,15.5f,0f,0f,0f,new float[][]{{112.0f,27.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg16",-3f,21f,22.0f,0f,0f,0f,new float[][]{{0.0f,30.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg17",3f,21f,22.0f,0f,0f,0f,new float[][]{{14.0f,30.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg18",-3f,21f,28.5f,0f,0f,0f,new float[][]{{28.0f,30.0f,-5.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("leg19",3f,21f,28.5f,0f,0f,0f,new float[][]{{42.0f,30.0f,0.0f,0.0f,-1.0f,5.0f,1.0f,2.0f}}),
            new PartSpec("head",0f,19f,-30f,0f,0f,0f,new float[][]{{100.0f,0.0f,-3.5f,-5.0f,-6.0f,7.0f,5.0f,6.0f},{56.0f,30.0f,-3.0f,-4.0f,-6.5f,1.0f,1.0f,1.0f},{60.0f,30.0f,2.0f,-4.0f,-6.5f,1.0f,1.0f,1.0f},{0.0f,22.0f,-6.0f,-2.0f,-8.0f,3.0f,1.0f,4.0f},{14.0f,22.0f,3.0f,-2.0f,-8.0f,3.0f,1.0f,4.0f}})}; }
    static final int TEX_CIEMPIES_COLOSAL=128;
    static PartSpec[] sanguijuela_abisal(){ return new PartSpec[]{
            new PartSpec("seg0",0f,12f,-4f,0f,0f,0f,new float[][]{{0.0f,0.0f,-3.0f,-4.0f,0.0f,6.0f,4.0f,5.0f}}),
            new PartSpec("seg1",0f,12f,1f,0f,0f,0f,new float[][]{{22.0f,0.0f,-2.5f,-4.0f,0.0f,5.0f,4.0f,4.0f}}),
            new PartSpec("seg2",0f,12f,5f,0f,0f,0f,new float[][]{{0.0f,9.0f,-2.5f,-3.0f,0.0f,5.0f,3.0f,4.0f}}),
            new PartSpec("seg3",0f,12f,9f,0f,0f,0f,new float[][]{{50.0f,9.0f,-2.0f,-3.0f,0.0f,4.0f,3.0f,3.0f}}),
            new PartSpec("seg4",0f,12f,12f,0f,0f,0f,new float[][]{{0.0f,16.0f,-1.5f,-2.0f,0.0f,3.0f,2.0f,3.0f}}),
            new PartSpec("head",0f,12f,-4f,0f,0f,0f,new float[][]{{40.0f,0.0f,-3.0f,-4.0f,-4.0f,6.0f,4.0f,4.0f},{12.0f,16.0f,-2.0f,-3.0f,-5.0f,4.0f,2.0f,1.0f},{22.0f,16.0f,-2.5f,-3.5f,-4.5f,1.0f,1.0f,1.0f},{26.0f,16.0f,1.5f,-3.5f,-4.5f,1.0f,1.0f,1.0f}}),
            new PartSpec("fin0",0f,12f,18f,0f,0f,0f,new float[][]{{18.0f,9.0f,-5.0f,-1.0f,0.0f,10.0f,1.0f,6.0f}})}; }
    static final int TEX_SANGUIJUELA_ABISAL=64;
    static PartSpec[] devorador_hongos(){ return new PartSpec[]{
            new PartSpec("body",0f,17f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-6.0f,-8.0f,-7.0f,12.0f,8.0f,14.0f},{52.0f,0.0f,-8.0f,-12.0f,-8.0f,16.0f,4.0f,16.0f},{0.0f,22.0f,-5.0f,-15.0f,-5.0f,10.0f,3.0f,10.0f},{46.0f,35.0f,-1.0f,-16.0f,-1.0f,2.0f,1.0f,2.0f}}),
            new PartSpec("head",0f,12.2f,-7.0f,0f,0f,0f,new float[][]{{40.0f,22.0f,-4.0f,-3.5f,-6.0f,8.0f,7.0f,6.0f},{30.0f,35.0f,-3.0f,1.0f,-8.0f,6.0f,2.0f,2.0f},{54.0f,35.0f,-3.5f,-2.0f,-6.5f,1.0f,1.0f,1.0f},{58.0f,35.0f,2.5f,-2.0f,-6.5f,1.0f,1.0f,1.0f}}),
            new PartSpec("leg0",-4.0f,17f,-3.0f,0f,0f,0f,new float[][]{{68.0f,22.0f,-2.0f,0.0f,-2.0f,4.0f,7.0f,4.0f}}),
            new PartSpec("leg1",4.0f,17f,-3.0f,0f,0f,0f,new float[][]{{84.0f,22.0f,-2.0f,0.0f,-2.0f,4.0f,7.0f,4.0f}}),
            new PartSpec("leg2",-4.0f,17f,3.0f,0f,0f,0f,new float[][]{{100.0f,22.0f,-2.0f,0.0f,-2.0f,4.0f,7.0f,4.0f}}),
            new PartSpec("leg3",4.0f,17f,3.0f,0f,0f,0f,new float[][]{{0.0f,35.0f,-2.0f,0.0f,-2.0f,4.0f,7.0f,4.0f}}),
            new PartSpec("tail0",0f,13.0f,7.0f,0f,0f,0f,new float[][]{{16.0f,35.0f,-1.5f,-1.5f,0.0f,3.0f,3.0f,4.0f}})}; }
    static final int TEX_DEVORADOR_HONGOS=128;
    static PartSpec[] espectro_cristal(){ return new PartSpec[]{
            new PartSpec("body",0f,10f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-4.0f,-10.0f,-3.0f,8.0f,10.0f,6.0f},{16.0f,16.0f,-5.0f,0.0f,-3.0f,10.0f,6.0f,6.0f},{0.0f,30.0f,-3.0f,6.0f,-2.0f,6.0f,6.0f,4.0f}}),
            new PartSpec("head",0f,0f,0f,0f,0f,0f,new float[][]{{28.0f,0.0f,-4.0f,-8.0f,-4.0f,8.0f,8.0f,8.0f},{8.0f,40.0f,-3.0f,-5.0f,-4.5f,2.0f,2.0f,1.0f},{14.0f,40.0f,1.0f,-5.0f,-4.5f,2.0f,2.0f,1.0f}}),
            new PartSpec("arm0",-6f,2f,0f,0f,0f,0f,new float[][]{{0.0f,16.0f,-1.0f,-1.0f,-1.0f,2.0f,12.0f,2.0f},{52.0f,30.0f,-1.0f,11.0f,-1.0f,2.0f,3.0f,2.0f}}),
            new PartSpec("arm1",6f,2f,0f,0f,0f,0f,new float[][]{{8.0f,16.0f,-1.0f,-1.0f,-1.0f,2.0f,12.0f,2.0f},{0.0f,40.0f,-1.0f,11.0f,-1.0f,2.0f,3.0f,2.0f}}),
            new PartSpec("orbit0",0f,8f,0f,0f,0.0f,0f,new float[][]{{20.0f,30.0f,8.0f,-7.0f,-1.0f,2.0f,5.0f,2.0f}}),
            new PartSpec("orbit1",0f,8f,0f,0f,1.5707963267948966f,0f,new float[][]{{28.0f,30.0f,10.0f,-7.0f,-1.0f,2.0f,5.0f,2.0f}}),
            new PartSpec("orbit2",0f,8f,0f,0f,3.141592653589793f,0f,new float[][]{{36.0f,30.0f,8.0f,-2.0f,-1.0f,2.0f,5.0f,2.0f}}),
            new PartSpec("orbit3",0f,8f,0f,0f,4.71238898038469f,0f,new float[][]{{44.0f,30.0f,10.0f,-2.0f,-1.0f,2.0f,5.0f,2.0f}})}; }
    static final int TEX_ESPECTRO_CRISTAL=64;
    static PartSpec[] cangrejo_cavernas(){ return new PartSpec[]{
            new PartSpec("body",0f,19f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-7.0f,-5.0f,-5.0f,14.0f,5.0f,10.0f},{0.0f,26.0f,-4.0f,-8.0f,-3.0f,8.0f,3.0f,6.0f}}),
            new PartSpec("head",0f,15f,-5f,0f,0f,0f,new float[][]{{24.0f,35.0f,-3.0f,-2.0f,-1.0f,6.0f,3.0f,2.0f},{40.0f,35.0f,-3.0f,-5.0f,-1.0f,1.0f,3.0f,1.0f},{44.0f,35.0f,2.0f,-5.0f,-1.0f,1.0f,3.0f,1.0f}}),
            new PartSpec("arm0",-7f,19f,-4f,0f,0f,0f,new float[][]{{28.0f,26.0f,-6.0f,-2.0f,-2.0f,6.0f,3.0f,3.0f},{0.0f,15.0f,-9.0f,-3.0f,-6.0f,5.0f,4.0f,7.0f},{46.0f,26.0f,-9.0f,-3.0f,-6.0f,1.0f,4.0f,2.0f}}),
            new PartSpec("arm1",7f,19f,-4f,0f,0f,0f,new float[][]{{0.0f,35.0f,0.0f,-2.0f,-2.0f,6.0f,3.0f,3.0f},{24.0f,15.0f,4.0f,-3.0f,-6.0f,5.0f,4.0f,7.0f},{18.0f,35.0f,8.0f,-3.0f,-6.0f,1.0f,4.0f,2.0f}}),
            new PartSpec("sleg0",-7f,20f,-2.0f,0f,0f,-0.5f,new float[][]{{0.0f,41.0f,-7.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}}),
            new PartSpec("sleg1",7f,20f,-2.0f,0f,0f,0.5f,new float[][]{{18.0f,41.0f,0.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}}),
            new PartSpec("sleg2",-7f,20f,1.5f,0f,0f,-0.5f,new float[][]{{36.0f,41.0f,-7.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}}),
            new PartSpec("sleg3",7f,20f,1.5f,0f,0f,0.5f,new float[][]{{0.0f,45.0f,0.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}}),
            new PartSpec("sleg4",-7f,20f,5.0f,0f,0f,-0.5f,new float[][]{{18.0f,45.0f,-7.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}}),
            new PartSpec("sleg5",7f,20f,5.0f,0f,0f,0.5f,new float[][]{{36.0f,45.0f,0.0f,-1.0f,-1.0f,7.0f,2.0f,2.0f}})}; }
    static final int TEX_CANGREJO_CAVERNAS=64;
    static PartSpec[] reptador_sombras(){ return new PartSpec[]{
            new PartSpec("body",0f,18f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-4.0f,-5.0f,-9.0f,8.0f,5.0f,18.0f}}),
            new PartSpec("head",0f,17f,-9f,0f,0f,0f,new float[][]{{0.0f,23.0f,-3.5f,-4.0f,-7.0f,7.0f,4.0f,7.0f},{56.0f,44.0f,-3.0f,-3.0f,-7.5f,1.0f,1.0f,1.0f},{60.0f,44.0f,2.0f,-3.0f,-7.5f,1.0f,1.0f,1.0f},{0.0f,50.0f,-0.5f,-3.0f,-7.5f,1.0f,1.0f,1.0f}}),
            new PartSpec("leg0",-4f,19f,-6f,0f,0f,0.25f,new float[][]{{20.0f,34.0f,-1.0f,0.0f,-1.0f,2.0f,5.0f,2.0f},{0.0f,44.0f,-1.0f,0.0f,-1.0f,2.0f,1.0f,5.0f}}),
            new PartSpec("leg1",4f,19f,-6f,0f,0f,-0.25f,new float[][]{{28.0f,34.0f,-1.0f,0.0f,-1.0f,2.0f,5.0f,2.0f},{14.0f,44.0f,-1.0f,0.0f,-1.0f,2.0f,1.0f,5.0f}}),
            new PartSpec("leg2",-4f,19f,5f,0f,0f,0.25f,new float[][]{{36.0f,34.0f,-1.0f,0.0f,-1.0f,2.0f,5.0f,2.0f},{28.0f,44.0f,-1.0f,0.0f,-1.0f,2.0f,1.0f,5.0f}}),
            new PartSpec("leg3",4f,19f,5f,0f,0f,-0.25f,new float[][]{{44.0f,34.0f,-1.0f,0.0f,-1.0f,2.0f,5.0f,2.0f},{42.0f,44.0f,-1.0f,0.0f,-1.0f,2.0f,1.0f,5.0f}}),
            new PartSpec("tail0",0f,18f,9f,0f,0f,0f,new float[][]{{28.0f,23.0f,-2.0f,-3.0f,0.0f,4.0f,3.0f,8.0f}}),
            new PartSpec("tail1",0f,18f,17f,0f,0f,0f,new float[][]{{0.0f,34.0f,-1.0f,-2.0f,0.0f,2.0f,2.0f,8.0f}})}; }
    static final int TEX_REPTADOR_SOMBRAS=64;
    static PartSpec[] coloso_subterraneo(){ return new PartSpec[]{
            new PartSpec("body",0f,10f,0f,0f,0f,0f,new float[][]{{64.0f,0.0f,-9.0f,-20.0f,-5.0f,18.0f,20.0f,10.0f},{104.0f,32.0f,-11.0f,-22.0f,-3.0f,5.0f,6.0f,6.0f},{0.0f,54.0f,6.0f,-22.0f,-3.0f,5.0f,6.0f,6.0f},{22.0f,54.0f,-2.0f,-14.0f,-5.2f,4.0f,6.0f,1.0f}}),
            new PartSpec("head",0f,-10f,0f,0f,0f,0f,new float[][]{{64.0f,32.0f,-5.0f,-10.0f,-5.0f,10.0f,10.0f,10.0f},{32.0f,54.0f,-6.0f,-12.0f,-4.0f,3.0f,3.0f,3.0f},{44.0f,54.0f,3.0f,-12.0f,-4.0f,3.0f,3.0f,3.0f},{56.0f,54.0f,-3.0f,-6.0f,-5.5f,2.0f,1.0f,1.0f},{62.0f,54.0f,1.0f,-6.0f,-5.5f,2.0f,1.0f,1.0f}}),
            new PartSpec("arm0",-13.0f,-8f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-4.0f,-2.0f,-4.0f,8.0f,24.0f,8.0f}}),
            new PartSpec("arm1",13.0f,-8f,0f,0f,0f,0f,new float[][]{{32.0f,0.0f,-4.0f,-2.0f,-4.0f,8.0f,24.0f,8.0f}}),
            new PartSpec("leg0",-4.8f,10f,0f,0f,0f,0f,new float[][]{{0.0f,32.0f,-4.0f,0.0f,-4.0f,8.0f,14.0f,8.0f}}),
            new PartSpec("leg1",4.8f,10f,0f,0f,0f,0f,new float[][]{{32.0f,32.0f,-4.0f,0.0f,-4.0f,8.0f,14.0f,8.0f}})}; }
    static final int TEX_COLOSO_SUBTERRANEO=128;
    static PartSpec[] serpiente_abisal(){ return new PartSpec[]{
            new PartSpec("seg0",0f,13f,-4f,0f,0f,0f,new float[][]{{42.0f,0.0f,-2.5f,-5.0f,0.0f,5.0f,5.0f,5.0f}}),
            new PartSpec("seg1",0f,13f,1f,0f,0f,0f,new float[][]{{0.0f,15.0f,-2.5f,-5.0f,0.0f,5.0f,5.0f,5.0f}}),
            new PartSpec("seg2",0f,13f,6f,0f,0f,0f,new float[][]{{20.0f,15.0f,-2.0f,-4.0f,0.0f,4.0f,4.0f,4.0f}}),
            new PartSpec("seg3",0f,13f,10f,0f,0f,0f,new float[][]{{36.0f,15.0f,-2.0f,-4.0f,0.0f,4.0f,4.0f,4.0f}}),
            new PartSpec("seg4",0f,13f,14f,0f,0f,0f,new float[][]{{0.0f,25.0f,-2.0f,-4.0f,0.0f,4.0f,4.0f,4.0f}}),
            new PartSpec("seg5",0f,13f,18f,0f,0f,0f,new float[][]{{16.0f,25.0f,-2.0f,-4.0f,0.0f,4.0f,4.0f,4.0f}}),
            new PartSpec("seg6",0f,13f,22f,0f,0f,0f,new float[][]{{32.0f,25.0f,-1.5f,-3.0f,0.0f,3.0f,3.0f,3.0f}}),
            new PartSpec("seg7",0f,13f,25f,0f,0f,0f,new float[][]{{44.0f,25.0f,-1.5f,-3.0f,0.0f,3.0f,3.0f,3.0f}}),
            new PartSpec("seg8",0f,13f,28f,0f,0f,0f,new float[][]{{0.0f,33.0f,-1.5f,-3.0f,0.0f,3.0f,3.0f,3.0f}}),
            new PartSpec("head",0f,13f,-4f,0f,0f,0f,new float[][]{{14.0f,0.0f,-3.5f,-5.0f,-7.0f,7.0f,5.0f,7.0f},{20.0f,33.0f,-3.0f,-4.0f,-7.5f,1.0f,1.0f,1.0f},{24.0f,33.0f,2.0f,-4.0f,-7.5f,1.0f,1.0f,1.0f},{12.0f,33.0f,-1.0f,-1.0f,-9.0f,2.0f,1.0f,2.0f}}),
            new PartSpec("fin0",0f,13f,48f,0f,0f,0f,new float[][]{{0.0f,0.0f,-1.0f,-5.0f,0.0f,2.0f,10.0f,5.0f}})}; }
    static final int TEX_SERPIENTE_ABISAL=64;
    static PartSpec[] devorador_almas(){ return new PartSpec[]{
            new PartSpec("body",0f,10f,0f,0f,0f,0f,new float[][]{{32.0f,0.0f,-6.0f,-14.0f,-3.0f,12.0f,14.0f,6.0f},{48.0f,22.0f,-7.0f,0.0f,-3.0f,14.0f,6.0f,6.0f},{88.0f,22.0f,-5.0f,6.0f,-2.0f,10.0f,5.0f,4.0f}}),
            new PartSpec("head",0f,-4f,0f,0f,0f,0f,new float[][]{{68.0f,0.0f,-5.0f,-9.0f,-5.0f,10.0f,9.0f,10.0f},{0.0f,22.0f,-6.0f,-10.0f,-6.0f,12.0f,3.0f,12.0f},{32.0f,37.0f,-3.5f,-6.0f,-5.5f,2.0f,2.0f,1.0f},{38.0f,37.0f,1.5f,-6.0f,-5.5f,2.0f,2.0f,1.0f},{44.0f,37.0f,-2.0f,-2.0f,-5.5f,4.0f,1.0f,1.0f}}),
            new PartSpec("arm0",-8f,-2f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-2.0f,-2.0f,-2.0f,4.0f,18.0f,4.0f},{0.0f,37.0f,-2.0f,16.0f,-2.0f,4.0f,3.0f,4.0f}}),
            new PartSpec("arm1",8f,-2f,0f,0f,0f,0f,new float[][]{{16.0f,0.0f,-2.0f,-2.0f,-2.0f,4.0f,18.0f,4.0f},{16.0f,37.0f,-2.0f,16.0f,-2.0f,4.0f,3.0f,4.0f}})}; }
    static final int TEX_DEVORADOR_ALMAS=128;
    static PartSpec[] guardian_ruinas(){ return new PartSpec[]{
            new PartSpec("body",0f,12f,0f,0f,0f,0f,new float[][]{{24.0f,0.0f,-5.0f,-14.0f,-3.0f,10.0f,14.0f,6.0f},{52.0f,22.0f,-1.0f,-9.0f,-3.2f,2.0f,3.0f,1.0f}}),
            new PartSpec("head",0f,-2f,0f,0f,0f,0f,new float[][]{{0.0f,22.0f,-4.0f,-8.0f,-4.0f,8.0f,8.0f,8.0f},{32.0f,22.0f,-1.0f,-12.0f,-4.0f,2.0f,4.0f,8.0f},{58.0f,22.0f,-3.0f,-5.0f,-4.5f,2.0f,1.0f,1.0f},{64.0f,22.0f,1.0f,-5.0f,-4.5f,2.0f,1.0f,1.0f}}),
            new PartSpec("arm0",-7.0f,0f,0f,0f,0f,0f,new float[][]{{56.0f,0.0f,-2.0f,-2.0f,-2.0f,4.0f,14.0f,4.0f}}),
            new PartSpec("arm1",7.0f,0f,0f,0f,0f,0f,new float[][]{{72.0f,0.0f,-2.0f,-2.0f,-2.0f,4.0f,14.0f,4.0f},{0.0f,0.0f,0.0f,2.0f,-5.0f,2.0f,12.0f,10.0f}}),
            new PartSpec("leg0",-3.0f,12f,0f,0f,0f,0f,new float[][]{{88.0f,0.0f,-2.5f,0.0f,-2.5f,5.0f,12.0f,5.0f}}),
            new PartSpec("leg1",3.0f,12f,0f,0f,0f,0f,new float[][]{{108.0f,0.0f,-2.5f,0.0f,-2.5f,5.0f,12.0f,5.0f}})}; }
    static final int TEX_GUARDIAN_RUINAS=128;
    static PartSpec[] bestia_magma(){ return new PartSpec[]{
            new PartSpec("body",0f,15f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-7.0f,-10.0f,-9.0f,14.0f,10.0f,18.0f},{28.0f,28.0f,-5.0f,-12.0f,-6.0f,10.0f,2.0f,12.0f},{0.0f,28.0f,-1.0f,-12.0f,-6.0f,2.0f,3.0f,12.0f}}),
            new PartSpec("head",0f,9.0f,-9.0f,0f,0f,0f,new float[][]{{64.0f,0.0f,-5.0f,-4.5f,-10.0f,10.0f,9.0f,10.0f},{62.0f,43.0f,-6.0f,-9.0f,-6.0f,2.0f,7.0f,2.0f},{70.0f,43.0f,4.0f,-9.0f,-6.0f,2.0f,7.0f,2.0f},{78.0f,43.0f,-3.0f,-1.0f,-10.5f,2.0f,1.0f,1.0f},{84.0f,43.0f,1.0f,-1.0f,-10.5f,2.0f,1.0f,1.0f}}),
            new PartSpec("leg0",-4.5f,15f,-4.0f,0f,0f,0f,new float[][]{{72.0f,28.0f,-2.5f,0.0f,-2.5f,5.0f,9.0f,5.0f}}),
            new PartSpec("leg1",4.5f,15f,-4.0f,0f,0f,0f,new float[][]{{92.0f,28.0f,-2.5f,0.0f,-2.5f,5.0f,9.0f,5.0f}}),
            new PartSpec("leg2",-4.5f,15f,4.0f,0f,0f,0f,new float[][]{{0.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,9.0f,5.0f}}),
            new PartSpec("leg3",4.5f,15f,4.0f,0f,0f,0f,new float[][]{{20.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,9.0f,5.0f}}),
            new PartSpec("tail0",0f,10.0f,9.0f,0f,0f,0f,new float[][]{{40.0f,43.0f,-1.5f,-1.5f,0.0f,3.0f,3.0f,8.0f}})}; }
    static final int TEX_BESTIA_MAGMA=128;
    static PartSpec[] cazador_invisible(){ return new PartSpec[]{
            new PartSpec("body",0f,12f,0f,0.35f,0f,0f,new float[][]{{16.0f,0.0f,-3.0f,-12.0f,-2.0f,6.0f,12.0f,4.0f}}),
            new PartSpec("head",0f,1f,-4f,0f,0f,0f,new float[][]{{36.0f,0.0f,-3.0f,-8.0f,-5.0f,6.0f,8.0f,5.0f},{36.0f,30.0f,-2.5f,-5.0f,-5.5f,1.0f,1.0f,1.0f},{40.0f,30.0f,1.5f,-5.0f,-5.5f,1.0f,1.0f,1.0f},{26.0f,30.0f,-1.5f,-2.0f,-6.5f,3.0f,2.0f,2.0f}}),
            new PartSpec("arm0",-4f,2f,-3f,-0.4f,0f,0f,new float[][]{{0.0f,0.0f,-1.0f,-1.0f,-1.0f,2.0f,16.0f,2.0f},{10.0f,30.0f,-1.5f,15.0f,-1.5f,3.0f,4.0f,1.0f}}),
            new PartSpec("arm1",4f,2f,-3f,-0.4f,0f,0f,new float[][]{{8.0f,0.0f,-1.0f,-1.0f,-1.0f,2.0f,16.0f,2.0f},{18.0f,30.0f,-1.5f,15.0f,-1.5f,3.0f,4.0f,1.0f}}),
            new PartSpec("leg0",-2f,11f,2f,0f,0f,0f,new float[][]{{24.0f,18.0f,-1.5f,0.0f,-1.5f,3.0f,6.0f,3.0f},{36.0f,18.0f,-1.5f,6.0f,-1.0f,3.0f,7.0f,2.0f}}),
            new PartSpec("leg1",2f,11f,2f,0f,0f,0f,new float[][]{{46.0f,18.0f,-1.5f,0.0f,-1.5f,3.0f,6.0f,3.0f},{0.0f,30.0f,-1.5f,6.0f,-1.0f,3.0f,7.0f,2.0f}}),
            new PartSpec("tail0",0f,12f,3f,0f,0f,0f,new float[][]{{0.0f,18.0f,-1.0f,-1.0f,0.0f,2.0f,2.0f,10.0f}})}; }
    static final int TEX_CAZADOR_INVISIBLE=64;
    static PartSpec[] hidra_cristal(){ return new PartSpec[]{
            new PartSpec("body",0f,16f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-7.0f,-9.0f,-10.0f,14.0f,9.0f,20.0f},{80.0f,43.0f,-2.0f,-14.0f,-6.0f,3.0f,6.0f,3.0f},{92.0f,43.0f,2.0f,-13.0f,0.0f,3.0f,5.0f,3.0f},{104.0f,43.0f,-4.0f,-12.0f,5.0f,3.0f,4.0f,3.0f}}),
            new PartSpec("tail0",0f,12f,10f,0f,0f,0f,new float[][]{{68.0f,0.0f,-2.0f,-3.0f,0.0f,4.0f,3.0f,12.0f}}),
            new PartSpec("leg0",-4.5f,16f,-5.0f,0f,0f,0f,new float[][]{{0.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,8.0f,5.0f}}),
            new PartSpec("leg1",4.5f,16f,-5.0f,0f,0f,0f,new float[][]{{20.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,8.0f,5.0f}}),
            new PartSpec("leg2",-4.5f,16f,5.0f,0f,0f,0f,new float[][]{{40.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,8.0f,5.0f}}),
            new PartSpec("leg3",4.5f,16f,5.0f,0f,0f,0f,new float[][]{{60.0f,43.0f,-2.5f,0.0f,-2.5f,5.0f,8.0f,5.0f}}),
            new PartSpec("neck0",-5f,10f,-8f,-0.3f,-0.25f,-0.3f,new float[][]{{100.0f,0.0f,-2.0f,-10.0f,-2.0f,4.0f,10.0f,4.0f}}),
            new PartSpec("head0",-8.0f,0f,-10f,0f,0f,0f,new float[][]{{0.0f,29.0f,-3.0f,-3.0f,-8.0f,6.0f,6.0f,8.0f},{84.0f,56.0f,-2.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{88.0f,56.0f,1.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{0.0f,56.0f,-2.0f,2.0f,-7.0f,4.0f,1.0f,6.0f},{60.0f,56.0f,-1.0f,-6.0f,-4.0f,2.0f,3.0f,2.0f}}),
            new PartSpec("neck1",0f,10f,-8f,-0.3f,0.0f,0.0f,new float[][]{{28.0f,29.0f,-2.0f,-10.0f,-2.0f,4.0f,10.0f,4.0f}}),
            new PartSpec("head1",0.0f,0f,-12f,0f,0f,0f,new float[][]{{44.0f,29.0f,-3.0f,-3.0f,-8.0f,6.0f,6.0f,8.0f},{92.0f,56.0f,-2.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{96.0f,56.0f,1.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{20.0f,56.0f,-2.0f,2.0f,-7.0f,4.0f,1.0f,6.0f},{68.0f,56.0f,-1.0f,-6.0f,-4.0f,2.0f,3.0f,2.0f}}),
            new PartSpec("neck2",5f,10f,-8f,-0.3f,0.25f,0.3f,new float[][]{{72.0f,29.0f,-2.0f,-10.0f,-2.0f,4.0f,10.0f,4.0f}}),
            new PartSpec("head2",8.0f,0f,-10f,0f,0f,0f,new float[][]{{88.0f,29.0f,-3.0f,-3.0f,-8.0f,6.0f,6.0f,8.0f},{100.0f,56.0f,-2.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{104.0f,56.0f,1.5f,-2.0f,-8.5f,1.0f,1.0f,1.0f},{40.0f,56.0f,-2.0f,2.0f,-7.0f,4.0f,1.0f,6.0f},{76.0f,56.0f,-1.0f,-6.0f,-4.0f,2.0f,3.0f,2.0f}})}; }
    static final int TEX_HIDRA_CRISTAL=128;
    static PartSpec[] leviatan_subterraneo(){ return new PartSpec[]{
            new PartSpec("seg0",0f,4f,-14f,0f,0f,0f,new float[][]{{0.0f,0.0f,-11.0f,-18.0f,0.0f,22.0f,18.0f,10.0f}}),
            new PartSpec("seg1",0f,4f,-4f,0f,0f,0f,new float[][]{{68.0f,28.0f,-9.5f,-15.0f,0.0f,19.0f,15.0f,9.0f}}),
            new PartSpec("seg2",0f,4f,5f,0f,0f,0f,new float[][]{{0.0f,56.0f,-8.0f,-13.0f,0.0f,16.0f,13.0f,7.0f}}),
            new PartSpec("seg3",0f,4f,12f,0f,0f,0f,new float[][]{{0.0f,76.0f,-6.5f,-10.0f,0.0f,13.0f,10.0f,6.0f}}),
            new PartSpec("seg4",0f,4f,18f,0f,0f,0f,new float[][]{{38.0f,76.0f,-5.0f,-8.0f,0.0f,10.0f,8.0f,4.0f}}),
            new PartSpec("head",0f,4f,-14f,0f,0f,0f,new float[][]{{0.0f,28.0f,-10.0f,-14.0f,-14.0f,20.0f,14.0f,14.0f},{44.0f,104.0f,-9.0f,-10.0f,-14.5f,3.0f,3.0f,1.0f},{52.0f,104.0f,6.0f,-10.0f,-14.5f,3.0f,3.0f,1.0f}}),
            new PartSpec("jaw",0f,18f,-14f,0f,0f,0f,new float[][]{{46.0f,56.0f,-9.0f,0.0f,-13.0f,18.0f,4.0f,13.0f},{60.0f,104.0f,-8.0f,-2.0f,-13.0f,2.0f,2.0f,2.0f},{68.0f,104.0f,6.0f,-2.0f,-13.0f,2.0f,2.0f,2.0f}}),
            new PartSpec("fin0",-9f,12f,-4f,0f,0f,0f,new float[][]{{68.0f,92.0f,-14.0f,0.0f,-3.0f,14.0f,2.0f,8.0f}}),
            new PartSpec("fin1",9f,12f,-4f,0f,0f,0f,new float[][]{{0.0f,104.0f,0.0f,0.0f,-3.0f,14.0f,2.0f,8.0f}}),
            new PartSpec("tail0",0f,12f,38f,0f,0f,0f,new float[][]{{0.0f,92.0f,-12.0f,-1.0f,0.0f,24.0f,2.0f,10.0f}})}; }
    static final int TEX_LEVIATAN_SUBTERRANEO=128;
    static PartSpec[] rey_abismo(){ return new PartSpec[]{
            new PartSpec("body",0f,6f,0f,0f,0f,0f,new float[][]{{0.0f,0.0f,-8.0f,-22.0f,-4.0f,16.0f,22.0f,8.0f},{92.0f,54.0f,-3.0f,-17.0f,-4.5f,6.0f,8.0f,1.0f},{48.0f,54.0f,-10.0f,-24.0f,-3.0f,5.0f,5.0f,6.0f},{70.0f,54.0f,5.0f,-24.0f,-3.0f,5.0f,5.0f,6.0f},{144.0f,0.0f,-8.0f,-4.0f,3.0f,16.0f,24.0f,1.0f}}),
            new PartSpec("head",0f,-16f,0f,0f,0f,0f,new float[][]{{0.0f,30.0f,-6.0f,-12.0f,-6.0f,12.0f,12.0f,12.0f},{114.0f,54.0f,-6.0f,-15.0f,-2.0f,2.0f,4.0f,2.0f},{106.0f,54.0f,-1.0f,-17.0f,-2.0f,2.0f,6.0f,2.0f},{122.0f,54.0f,4.0f,-15.0f,-2.0f,2.0f,4.0f,2.0f},{0.0f,54.0f,-6.0f,-13.0f,-6.0f,12.0f,2.0f,12.0f},{130.0f,54.0f,-4.0f,-8.0f,-6.5f,3.0f,2.0f,1.0f},{138.0f,54.0f,1.0f,-8.0f,-6.5f,3.0f,2.0f,1.0f}}),
            new PartSpec("arm0",-11.0f,-14f,0f,0f,0f,0f,new float[][]{{48.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,22.0f,6.0f}}),
            new PartSpec("arm1",11.0f,-14f,0f,0f,0f,0f,new float[][]{{72.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,22.0f,6.0f}}),
            new PartSpec("arm2",-11.0f,-9f,0f,0f,0f,0f,new float[][]{{96.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,22.0f,6.0f}}),
            new PartSpec("arm3",11.0f,-9f,0f,0f,0f,0f,new float[][]{{120.0f,0.0f,-3.0f,-2.0f,-3.0f,6.0f,22.0f,6.0f}}),
            new PartSpec("leg0",-4.2f,6f,0f,0f,0f,0f,new float[][]{{178.0f,0.0f,-3.5f,0.0f,-3.5f,7.0f,18.0f,7.0f}}),
            new PartSpec("leg1",4.2f,6f,0f,0f,0f,0f,new float[][]{{206.0f,0.0f,-3.5f,0.0f,-3.5f,7.0f,18.0f,7.0f}}),
            new PartSpec("wing0",-4f,-10f,4f,0f,0.3f,-0.2f,new float[][]{{48.0f,30.0f,-26.0f,-2.0f,0.0f,26.0f,1.0f,16.0f}}),
            new PartSpec("wing1",4f,-10f,4f,0f,-0.3f,0.2f,new float[][]{{132.0f,30.0f,0.0f,-2.0f,0.0f,26.0f,1.0f,16.0f}})}; }
    static final int TEX_REY_ABISMO=256;
    public static PartSpec[] get(String id) {
        switch (id) {
            case "acechador_abisal": return acechador_abisal();
            case "arana_cristalina": return arana_cristalina();
            case "gusano_profundidades": return gusano_profundidades();
            case "murcielago_gigante": return murcielago_gigante();
            case "golem_obsidiana": return golem_obsidiana();
            case "ciempies_colosal": return ciempies_colosal();
            case "sanguijuela_abisal": return sanguijuela_abisal();
            case "devorador_hongos": return devorador_hongos();
            case "espectro_cristal": return espectro_cristal();
            case "cangrejo_cavernas": return cangrejo_cavernas();
            case "reptador_sombras": return reptador_sombras();
            case "coloso_subterraneo": return coloso_subterraneo();
            case "serpiente_abisal": return serpiente_abisal();
            case "devorador_almas": return devorador_almas();
            case "guardian_ruinas": return guardian_ruinas();
            case "bestia_magma": return bestia_magma();
            case "cazador_invisible": return cazador_invisible();
            case "hidra_cristal": return hidra_cristal();
            case "leviatan_subterraneo": return leviatan_subterraneo();
            case "rey_abismo": return rey_abismo();
            default: throw new IllegalArgumentException(id);
        }
    }
    public static int texSize(String id) {
        switch (id) {
            case "acechador_abisal": return TEX_ACECHADOR_ABISAL;
            case "arana_cristalina": return TEX_ARANA_CRISTALINA;
            case "gusano_profundidades": return TEX_GUSANO_PROFUNDIDADES;
            case "murcielago_gigante": return TEX_MURCIELAGO_GIGANTE;
            case "golem_obsidiana": return TEX_GOLEM_OBSIDIANA;
            case "ciempies_colosal": return TEX_CIEMPIES_COLOSAL;
            case "sanguijuela_abisal": return TEX_SANGUIJUELA_ABISAL;
            case "devorador_hongos": return TEX_DEVORADOR_HONGOS;
            case "espectro_cristal": return TEX_ESPECTRO_CRISTAL;
            case "cangrejo_cavernas": return TEX_CANGREJO_CAVERNAS;
            case "reptador_sombras": return TEX_REPTADOR_SOMBRAS;
            case "coloso_subterraneo": return TEX_COLOSO_SUBTERRANEO;
            case "serpiente_abisal": return TEX_SERPIENTE_ABISAL;
            case "devorador_almas": return TEX_DEVORADOR_ALMAS;
            case "guardian_ruinas": return TEX_GUARDIAN_RUINAS;
            case "bestia_magma": return TEX_BESTIA_MAGMA;
            case "cazador_invisible": return TEX_CAZADOR_INVISIBLE;
            case "hidra_cristal": return TEX_HIDRA_CRISTAL;
            case "leviatan_subterraneo": return TEX_LEVIATAN_SUBTERRANEO;
            case "rey_abismo": return TEX_REY_ABISMO;
            default: return 128;
        }
    }
}

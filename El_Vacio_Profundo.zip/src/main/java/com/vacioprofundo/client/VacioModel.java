package com.vacioprofundo.client;

import com.vacioprofundo.client.ModelSpecs.PartSpec;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Data-driven model: anatomy comes from ModelSpecs (one distinct skeleton per species).
 * Animation is selected by part-name prefix: leg/sleg (walk/run), seg/tail (undulation), wing/fin (flap),
 * arm (swing + attack + special raise), head/neck (look, sway), jaw (bite), orbit (floating shards).
 */
public class VacioModel extends EntityModel<VacioRenderState> {
    private final PartSpec[] specs;
    private final ModelPart[] parts;

    public VacioModel(ModelPart root, String id) {
        super(root);
        specs = ModelSpecs.get(id);
        parts = new ModelPart[specs.length];
        for (int i = 0; i < specs.length; i++) parts[i] = root.getChild(specs[i].name());
    }

    public static LayerDefinition createLayer(String id) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        for (PartSpec s : ModelSpecs.get(id)) {
            CubeListBuilder b = CubeListBuilder.create();
            for (float[] bx : s.boxes()) b.texOffs((int) bx[0], (int) bx[1]).addBox(bx[2], bx[3], bx[4], bx[5], bx[6], bx[7]);
            root.addOrReplaceChild(s.name(), b, PartPose.offsetAndRotation(s.px(), s.py(), s.pz(), s.rx(), s.ry(), s.rz()));
        }
        int tex = ModelSpecs.texSize(id);
        return LayerDefinition.create(mesh, tex, tex);
    }

    private static int idx(String n) {
        int k = n.length();
        while (k > 0 && Character.isDigit(n.charAt(k - 1))) k--;
        return k == n.length() ? 0 : Integer.parseInt(n.substring(k));
    }

    @Override
    public void setupAnim(VacioRenderState s) {
        super.setupAnim(s);
        float pos = s.walkAnimationPos, spd = Math.min(1f, s.walkAnimationSpeed * (s.aggressive ? 1.5f : 1f)), age = s.ageInTicks;
        float atk = s.attackTime > 0 ? (float) Math.sin(s.attackTime * Math.PI) : 0f;
        float spc = s.special;
        for (int i = 0; i < specs.length; i++) {
            PartSpec sp = specs[i]; ModelPart p = parts[i]; String n = sp.name(); int k = idx(n);
            if (n.startsWith("head")) {
                p.yRot = sp.ry() + s.yRot * 0.017453292f * (n.length() > 4 ? 0.6f : 1f);
                p.xRot = sp.rx() + s.xRot * 0.017453292f + (s.resting ? 0.35f : 0f) + (n.length() > 4 ? (float) Math.sin(age * 0.09f + k * 1.7f) * 0.12f + atk * 0.5f * (k % 2 == 0 ? 1 : -1) : 0f);
            } else if (n.startsWith("neck")) {
                p.xRot = sp.rx() + (float) Math.sin(age * 0.07f + k) * 0.06f;
            } else if (n.startsWith("sleg")) {
                p.yRot = sp.ry() + (float) Math.sin(pos * 0.8f + k * 1.1f) * 0.55f * spd;
                p.zRot = sp.rz() + (float) Math.sin(age * 0.1f + k) * 0.03f + Math.max(0f, (float) Math.cos(pos * 0.8f + k * 1.1f)) * 0.25f * spd * Math.signum(sp.rz());
            } else if (n.startsWith("leg")) {
                p.xRot = sp.rx() + (float) Math.cos(pos * 0.6662f + (k % 2 == 0 ? 0f : (float) Math.PI)) * 1.4f * spd;
            } else if (n.startsWith("arm")) {
                float sw = (float) Math.cos(pos * 0.6662f + (k % 2 == 0 ? (float) Math.PI : 0f)) * spd;
                p.xRot = sp.rx() + sw - atk * 1.9f - spc * 1.5f + (s.resting ? 0.1f : 0f);
                p.zRot = sp.rz() + (k % 2 == 0 ? 1 : -1) * (spc * 0.4f + (float) Math.sin(age * 0.09f) * 0.04f);
            } else if (n.startsWith("seg")) {
                p.yRot = sp.ry() + (float) Math.sin(age * 0.12f - k * 0.7f + pos * 0.5f) * (0.10f + 0.35f * spd);
                p.xRot = sp.rx() - (k == 0 ? atk * 0.4f : 0f);
            } else if (n.startsWith("tail")) {
                p.yRot = sp.ry() + (float) Math.sin(age * 0.1f - k) * (0.15f + 0.3f * spd);
            } else if (n.startsWith("wing")) {
                float f = (float) Math.sin(age * (s.aggressive ? 1.1f : 0.7f)) * 0.7f;
                p.zRot = sp.rz() + (k % 2 == 0 ? f : -f);
            } else if (n.startsWith("fin")) {
                p.zRot = sp.rz() + (k % 2 == 0 ? 1 : -1) * (float) Math.sin(age * 0.2f + pos) * 0.35f;
                p.yRot = sp.ry() + (float) Math.sin(age * 0.1f) * 0.15f;
            } else if (n.startsWith("jaw")) {
                p.xRot = sp.rx() + Math.max(atk, spc) * 0.7f + (float) Math.sin(age * 0.1f) * 0.03f;
            } else if (n.startsWith("orbit")) {
                p.yRot = sp.ry() + age * 0.06f;
            } else if (n.equals("body") || n.equals("abdomen")) {
                p.xRot = sp.rx() + (float) Math.sin(age * 0.08f) * 0.015f - (s.resting ? 0.05f : 0f);
            }
        }
    }
}

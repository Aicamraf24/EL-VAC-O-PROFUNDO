package com.vacioprofundo.client;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.entity.VacioBase;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class VacioRenderer extends MobRenderer<VacioBase, VacioRenderState, VacioModel> {
    private final Identifier texture;

    public VacioRenderer(EntityRendererProvider.Context ctx, String id, float shadow) {
        super(ctx, new VacioModel(ctx.bakeLayer(VacioClient.layer(id)), id), shadow);
        this.texture = VacioProfundo.id("textures/entity/" + id + ".png");
    }

    @Override public VacioRenderState createRenderState() { return new VacioRenderState(); }

    @Override
    public void extractRenderState(VacioBase e, VacioRenderState s, float partialTick) {
        super.extractRenderState(e, s, partialTick);
        s.special = e.specialAmount();
        s.aggressive = e.isAggressive();
        s.resting = e.isResting();
        s.phase = e.phase();
    }

    @Override public Identifier getTextureLocation(VacioRenderState state) { return texture; }
}

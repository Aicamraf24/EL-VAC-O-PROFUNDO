package com.vacioprofundo.client;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.world.entity.EntityType;
import java.util.Map;

@SuppressWarnings({"unchecked", "rawtypes"})
public class VacioClient implements ClientModInitializer {
    public static ModelLayerLocation layer(String id) { return new ModelLayerLocation(VacioProfundo.id(id), "main"); }

    @Override
    public void onInitializeClient() {
        for (Map.Entry<String, EntityType<?>> e : ModEntities.TYPES.entrySet()) {
            String id = e.getKey();
            EntityModelLayerRegistry.registerModelLayer(layer(id), () -> VacioModel.createLayer(id));
            float shadow = switch (id) { case "leviatan_subterraneo" -> 2.5f; case "rey_abismo", "coloso_subterraneo", "hidra_cristal" -> 1.6f; case "murcielago_gigante", "espectro_cristal" -> 0.3f; default -> 0.6f; };
            EntityRendererRegistry.register((EntityType) e.getValue(), ctx -> new VacioRenderer(ctx, id, shadow));
        }
    }
}

package com.vacioprofundo.portal;

import com.vacioprofundo.VacioProfundo;
import com.vacioprofundo.registry.ModBlocks;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

/**
 * Portal logic. Frame: rectangle of Marco del Vacío (min inner 2x3, max 21x21) lit with a Núcleo del Vacío.
 * Players standing 2 seconds inside Portal del Vacío are moved (inventory and progress are untouched).
 */
public final class PortalHandler {
    private PortalHandler() {}
    public static final ResourceKey<Level> VACIO = ResourceKey.create(Registries.DIMENSION, VacioProfundo.id("vacio_profundo"));
    private static final Map<UUID, Integer> DWELL = new HashMap<>();
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();

    private static BlockState frame() { return ModBlocks.MARCO_VACIO.defaultBlockState(); }
    private static BlockState portal() { return ModBlocks.PORTAL_VACIO.defaultBlockState(); }

    // ---------- activation ----------
    public static boolean tryActivate(Level level, BlockPos start) {
        for (boolean alongX : new boolean[]{true, false}) {
            int dx = alongX ? 1 : 0, dz = alongX ? 0 : 1;
            BlockPos p = start;
            int guard = 0;
            while (level.getBlockState(p.below()).isAir() && guard++ < 21) p = p.below();
            if (!level.getBlockState(p).isAir() && !level.getBlockState(p).is(Blocks.FIRE)) continue;
            int left = 0;
            while (left < 22 && level.getBlockState(p.offset(-(left + 1) * dx, 0, -(left + 1) * dz)).isAir()) left++;
            if (!level.getBlockState(p.offset(-(left + 1) * dx, 0, -(left + 1) * dz)).is(frame().getBlock())) continue;
            BlockPos origin = p.offset(-left * dx, 0, -left * dz);
            int width = 0;
            while (width < 22 && level.getBlockState(origin.offset(width * dx, 0, width * dz)).isAir()) width++;
            if (width < 2 || width > 21 || !level.getBlockState(origin.offset(width * dx, 0, width * dz)).is(frame().getBlock())) continue;
            int height = 0;
            while (height < 22 && level.getBlockState(origin.above(height)).isAir()) height++;
            if (height < 3 || height > 21 || !level.getBlockState(origin.above(height)).is(frame().getBlock())) continue;
            boolean ok = true;
            for (int w = 0; w < width && ok; w++) {
                if (!level.getBlockState(origin.offset(w * dx, -1, w * dz)).is(frame().getBlock())) ok = false;
                if (!level.getBlockState(origin.offset(w * dx, height, w * dz)).is(frame().getBlock())) ok = false;
            }
            for (int h = 0; h < height && ok; h++) {
                if (!level.getBlockState(origin.offset(-dx, h, -dz)).is(frame().getBlock())) ok = false;
                if (!level.getBlockState(origin.offset(width * dx, h, width * dz)).is(frame().getBlock())) ok = false;
                for (int w = 0; w < width && ok; w++) if (!level.getBlockState(origin.offset(w * dx, h, w * dz)).isAir()) ok = false;
            }
            if (!ok) continue;
            for (int w = 0; w < width; w++) for (int h = 0; h < height; h++) level.setBlock(origin.offset(w * dx, h, w * dz), portal(), 3);
            return true;
        }
        return false;
    }

    // ---------- teleport ----------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 5 != 0) return;
            for (ServerLevel lvl : server.getAllLevels()) {
                for (ServerPlayer p : lvl.players()) {
                    UUID id = p.getUUID();
                    int cd = COOLDOWN.getOrDefault(id, 0);
                    if (cd > 0) COOLDOWN.put(id, cd - 1);
                    boolean inside = lvl.getBlockState(p.blockPosition()).is(ModBlocks.PORTAL_VACIO) || lvl.getBlockState(p.blockPosition().above()).is(ModBlocks.PORTAL_VACIO);
                    if (!inside) { DWELL.remove(id); continue; }
                    lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 4, .3, .6, .3, .02);
                    if (cd > 0) continue;
                    int d = DWELL.merge(id, 1, Integer::sum);
                    if (d >= 8) { DWELL.remove(id); COOLDOWN.put(id, 12); teleport(server, p, lvl); }
                }
            }
        });
    }

    private static void teleport(MinecraftServer server, ServerPlayer p, ServerLevel from) {
        boolean toVoid = !from.dimension().equals(VACIO);
        ServerLevel dest = server.getLevel(toVoid ? VACIO : Level.OVERWORLD);
        if (dest == null) return;
        int x = p.blockPosition().getX(), z = p.blockPosition().getZ();
        BlockPos portalBase = findPortal(dest, x, z);
        if (portalBase == null) {
            portalBase = toVoid ? findVoidFloor(dest, x, z) : new BlockPos(x, dest.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z);
            build(dest, portalBase);
        }
        Vec3 pos = new Vec3(portalBase.getX() + 1.0, portalBase.getY(), portalBase.getZ() + 2.5);
        p.teleport(new TeleportTransition(dest, pos, Vec3.ZERO, 180f, 0f, TeleportTransition.DO_NOTHING));
    }

    private static BlockPos findPortal(ServerLevel lvl, int x, int z) {
        int lo = lvl.getMinY() + 2, hi = lvl.getMaxY() - 2;
        BlockPos best = null; double bd = 1e9;
        for (int dx = -8; dx <= 8; dx++) for (int dz = -8; dz <= 8; dz++) {
            lvl.getChunk((x + dx) >> 4, (z + dz) >> 4);
            for (int y = hi; y >= lo; y--) {
                BlockPos b = new BlockPos(x + dx, y, z + dz);
                if (lvl.getBlockState(b).is(ModBlocks.PORTAL_VACIO) && lvl.getBlockState(b.below()).is(ModBlocks.MARCO_VACIO)) {
                    double d = dx * dx + dz * dz; if (d < bd) { bd = d; best = b; }
                }
            }
        }
        return best == null ? null : new BlockPos(best.getX(), best.getY(), best.getZ() - 0);
    }

    private static BlockPos findVoidFloor(ServerLevel lvl, int x, int z) {
        for (int r = 0; r <= 64; r += 8) for (int dx = -r; dx <= r; dx += 8) for (int dz = -r; dz <= r; dz += 8) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
            lvl.getChunk((x + dx) >> 4, (z + dz) >> 4);
            for (int y = 120; y > -30; y--) {
                BlockPos b = new BlockPos(x + dx, y, z + dz);
                if (!lvl.getBlockState(b).isAir() && lvl.getBlockState(b).getFluidState().isEmpty()
                    && lvl.getBlockState(b.above()).isAir() && lvl.getBlockState(b.above(2)).isAir() && lvl.getBlockState(b.above(3)).isAir()) return b.above();
            }
        }
        return new BlockPos(x, 40, z);
    }

    /** 2x3 portal lying on a 7x7 platform; inner bottom-left corner at base. */
    private static void build(ServerLevel lvl, BlockPos base) {
        for (int dx = -3; dx <= 4; dx++) for (int dz = -2; dz <= 4; dz++) {
            lvl.setBlock(base.offset(dx, -1, dz), ModBlocks.BALDOSA_ANTIGUA.defaultBlockState(), 3);
            for (int dy = 0; dy <= 4; dy++) if (!(dz == 0 && dx >= -1 && dx <= 2 && dy <= 3)) lvl.setBlock(base.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 3);
        }
        for (int dx = -1; dx <= 2; dx++) for (int dy = -1; dy <= 3; dy++) {
            boolean edge = dx == -1 || dx == 2 || dy == -1 || dy == 3;
            lvl.setBlock(base.offset(dx, dy, 0), edge ? frame() : portal(), 3);
        }
    }
}

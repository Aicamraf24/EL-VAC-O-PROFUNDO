package com.vacioprofundo.events;

import com.vacioprofundo.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;

/** Full-set bonuses, evaluated every 40 ticks per player (cheap). */
public final class SetBonuses {
    private SetBonuses() {}

    private static boolean full(ServerPlayer p, Item h, Item c, Item l, Item b) {
        return p.getItemBySlot(EquipmentSlot.HEAD).is(h) && p.getItemBySlot(EquipmentSlot.CHEST).is(c)
            && p.getItemBySlot(EquipmentSlot.LEGS).is(l) && p.getItemBySlot(EquipmentSlot.FEET).is(b);
    }

    public static void init() {
        ServerTickEvents.END_LEVEL_TICK.register(level -> {
            if (level.getGameTime() % 40 != 0) return;
            for (ServerPlayer p : level.players()) {
                if (full(p, ModItems.CASCO_CRISTAL_ABISAL, ModItems.PETO_CRISTAL_ABISAL, ModItems.PANTALONES_CRISTAL_ABISAL, ModItems.BOTAS_CRISTAL_ABISAL))
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false, true));
                if (full(p, ModItems.CASCO_PIEDRA_ASTRAL, ModItems.PETO_PIEDRA_ASTRAL, ModItems.PANTALONES_PIEDRA_ASTRAL, ModItems.BOTAS_PIEDRA_ASTRAL))
                    p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 0, true, false, true));
                if (full(p, ModItems.CASCO_OBSIDIANA_VIVIENTE, ModItems.PETO_OBSIDIANA_VIVIENTE, ModItems.PANTALONES_OBSIDIANA_VIVIENTE, ModItems.BOTAS_OBSIDIANA_VIVIENTE))
                    p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false, true));
                if (full(p, ModItems.CASCO_CAZADOR, ModItems.PETO_CAZADOR, ModItems.PANTALONES_CAZADOR, ModItems.BOTAS_CAZADOR)) {
                    p.addEffect(new MobEffectInstance(MobEffects.SPEED, 100, 0, true, false, true));
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false, true));
                }
                if (full(p, ModItems.CASCO_VACIO, ModItems.PETO_VACIO, ModItems.PANTALONES_VACIO, ModItems.BOTAS_VACIO)) {
                    p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, 1, true, false, true));
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, false, true));
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false, true));
                    p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, true, false, true));
                }
            }
        });
    }
}

package com.vacioprofundo.events;

import com.vacioprofundo.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

/** Shadow Dagger backstab (+4 damage from behind) and Dimensional Bow (gravity-free arrows, 4s lifetime). */
public final class WeaponAbilities {
    private WeaponAbilities() {}
    private static boolean busy = false;
    private static final List<Projectile> TRACKED = new ArrayList<>();

    public static void init() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, takenDamage, blocked) -> {
            if (busy || blocked || !(entity.level() instanceof ServerLevel sl)) return;
            if (!(source.getEntity() instanceof LivingEntity attacker)) return;
            if (!attacker.getMainHandItem().is(ModItems.DAGA_SOMBRAS)) return;
            Vec3 toAttacker = attacker.position().subtract(entity.position()).normalize();
            if (entity.getLookAngle().normalize().dot(toAttacker) < -0.1) {
                busy = true;
                try { entity.hurtServer(sl, source, 4.0f); } finally { busy = false; }
            }
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity.getType() == EntityType.ARROW && entity instanceof Projectile arrow && arrow.getOwner() instanceof LivingEntity owner
                && arrow.tickCount == 0
                && (owner.getMainHandItem().is(ModItems.ARCO_DIMENSIONAL) || owner.getOffhandItem().is(ModItems.ARCO_DIMENSIONAL))) {
                arrow.setNoGravity(true);
                TRACKED.add(arrow);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            TRACKED.removeIf(a -> {
                if (a.isRemoved()) return true;
                if (a.tickCount > 80) { a.discard(); return true; }
                return false;
            });
        });
    }
}

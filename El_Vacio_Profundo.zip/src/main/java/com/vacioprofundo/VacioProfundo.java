package com.vacioprofundo;

import com.vacioprofundo.events.SetBonuses;
import com.vacioprofundo.events.WeaponAbilities;
import com.vacioprofundo.portal.PortalHandler;
import com.vacioprofundo.registry.ModBlocks;
import com.vacioprofundo.registry.ModEntities;
import com.vacioprofundo.registry.ModItems;
import com.vacioprofundo.worldgen.ModFeatures;
import com.vacioprofundo.worldgen.structure.ModStructures;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

/** Entry point of "El Vacío Profundo". Unique mod id: vacio_profundo (no overlap with other mods). */
public class VacioProfundo implements ModInitializer {
    public static final String MOD_ID = "vacio_profundo";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        ModFeatures.init();
        ModStructures.init();
        PortalHandler.init();
        SetBonuses.init();
        WeaponAbilities.init();
    }
}

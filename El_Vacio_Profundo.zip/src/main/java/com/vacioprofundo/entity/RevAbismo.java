package com.vacioprofundo.entity;

import com.vacioprofundo.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.Identifier;

/**
 * Rey del Abismo - final boss. 3 phases by health:
 *  1 (100-66%): void bolts + melee.
 *  2 (66-33%): ground slam AoE + summons Acechadores / Reptadores.
 *  3 (<33%): enraged (+30% speed), triple bolts, soul drain and gravity pull.
 * Sleeps (heals, no attacks) until a player is within 40 blocks.
 */
public class RevAbismo extends VacioBase {
    private final ServerBossEvent bossEvent = new ServerBossEvent(Component.translatable("entity.vacio_profundo.rey_abismo"),
        BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int boltCd = 40, slamCd = 100, summonCd = 200, drainCd = 120, lastPhase = 1;
    private static final Identifier ENRAGE = Identifier.fromNamespaceAndPath("vacio_profundo", "enrage");

    public RevAbismo(EntityType<? extends RevAbismo> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0f);
        this.fireImmune = true;
        setPersistenceRequired();
        buildGoals();
    }

    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(450, 16, 0.27, 48, 12, 1.0);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean canUsePortal(boolean allowPassengers) { return false; }
    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }

    private int bossPhase() {
        float f = getHealth() / getMaxHealth();
        return f > 0.66f ? 1 : f > 0.33f ? 2 : 3;
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide() || !(level() instanceof ServerLevel sl)) return;
        bossEvent.setProgress(getHealth() / getMaxHealth());
        int ph = bossPhase();
        setStateBits(false, boltCd > 25, ph);
        if (ph != lastPhase) {
            lastPhase = ph;
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 2, getZ(), 1, 0, 0, 0, 0);
            if (ph == 3) {
                AttributeInstance sp = getAttribute(Attributes.MOVEMENT_SPEED);
                if (sp != null && !sp.hasModifier(ENRAGE)) sp.addTransientModifier(new AttributeModifier(ENRAGE, 0.3, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
            }
        }
        Player near = sl.getNearestPlayer(this, 40);
        if (near == null) { if (tickCount % 20 == 0) heal(4f); return; }
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) return;
        double dist = distanceTo(t);
        if (--boltCd <= 0 && dist < 22) {
            boltCd = ph == 3 ? 35 : 60;
            for (int i = 0; i < (ph == 3 ? 3 : 1); i++) ray(sl, t, 6f, ParticleTypes.DRAGON_BREATH);
        }
        if (ph >= 2 && --slamCd <= 0 && dist < 8) {
            slamCd = 100;
            aoe(sl, 7.0, 10f, 1.4);
            sl.sendParticles(ParticleTypes.POOF, getX(), getY() + .2, getZ(), 40, 3.5, .1, 3.5, .03);
        }
        if (ph >= 2 && --summonCd <= 0) {
            summonCd = ph == 3 ? 160 : 240;
            long minions = sl.getEntitiesOfClass(VacioBase.class, getBoundingBox().inflate(24), e -> e != this).size();
            if (minions < 6) for (int i = 0; i < 2; i++) summon(sl, i % 2 == 0 ? ModEntities.ACECHADOR_ABISAL : ModEntities.REPTADOR_SOMBRAS);
        }
        if (ph == 3 && --drainCd <= 0 && dist < 16) {
            drainCd = 120;
            Vec3 pull = position().subtract(t.position()).normalize().scale(0.7);
            t.setDeltaMovement(t.getDeltaMovement().add(pull)); t.hurtMarked = true;
            t.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1));
            heal(10f);
        }
    }

    private void summon(ServerLevel sl, EntityType<? extends VacioBase> type) {
        VacioBase m = type.create(sl, EntitySpawnReason.MOB_SUMMONED);
        if (m == null) return;
        m.setPos(getX() + (random.nextDouble() - .5) * 8, getY(), getZ() + (random.nextDouble() - .5) * 8);
        if (getTarget() != null) m.setTarget(getTarget());
        sl.addFreshEntity(m);
    }
}

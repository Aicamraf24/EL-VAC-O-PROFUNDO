package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Devorador de Almas - HOSTILE / floater. */
public class DevoradorAlmas extends VacioBase {
    public static final String ID = "devorador_almas";
    public DevoradorAlmas(EntityType<? extends DevoradorAlmas> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        makeFlyer();
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(60, 8, 0.26, 32, 2, 0.4);
    }
    @Override protected int abilityInterval() { return 60; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<10){ ray(level,target,5f,ParticleTypes.SOUL); heal(3f); target.addEffect(new MobEffectInstance(MobEffects.WITHER,60,0)); }
    }
}

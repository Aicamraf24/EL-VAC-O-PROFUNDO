package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Guardián de las Ruinas - TERRITORIAL / ground. */
public class GuardianRuinas extends VacioBase {
    public static final String ID = "guardian_ruinas";
    public GuardianRuinas(EntityType<? extends GuardianRuinas> type, Level level) {
        super(type, level, Behavior.TERRITORIAL, 0.0f);
        
        keepHome=true;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(64, 8, 0.23, 20, 8, 0.8);
    }
    @Override protected int abilityInterval() { return 90; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist>5&&dist<13){ Vec3 d=target.position().subtract(position()).normalize().scale(.9); setDeltaMovement(d.x,.2,d.z); }
    }
}

package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Reptador de las Sombras - AMBUSH / ground. */
public class ReptadorSombras extends VacioBase {
    public static final String ID = "reptador_sombras";
    public ReptadorSombras(EntityType<? extends ReptadorSombras> type, Level level) {
        super(type, level, Behavior.AMBUSH, 0.0f);
        
        onHitEffect=MobEffects.BLINDNESS;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(26, 6, 0.36, 22, 0, 0);
    }
    @Override protected int abilityInterval() { return 0; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        
    }
}

package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Leviatán Subterráneo - HOSTILE / swimmer. */
public class LeviatanSubterraneo extends VacioBase {
    public static final String ID = "leviatan_subterraneo";
    public LeviatanSubterraneo(EntityType<? extends LeviatanSubterraneo> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        makeSwimmer();
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(170, 16, 0.9, 40, 8, 1.0);
    }
    @Override protected int abilityInterval() { return 90; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<14){ Vec3 pull=position().subtract(target.position()).normalize().scale(.5); target.setDeltaMovement(target.getDeltaMovement().add(pull)); target.hurtMarked=true; } if(dist<6) aoe(level,5.0,8f,.7);
    }
}

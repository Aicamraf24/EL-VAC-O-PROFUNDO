package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import com.vacioprofundo.registry.ModItems;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Devorador de Hongos - NEUTRAL / ground. */
public class DevoradorHongos extends VacioBase {
    public static final String ID = "devorador_hongos";
    public DevoradorHongos(EntityType<? extends DevoradorHongos> type, Level level) {
        super(type, level, Behavior.NEUTRAL, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(36, 5, 0.24, 16, 2, 0.3);
    }
    @Override protected boolean isFood(ItemStack stack) { return stack.is(ModItems.ESPORA_BRILLANTE); }
    @Override protected int abilityInterval() { return 100; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<5) { for(Player p: level.getEntitiesOfClass(Player.class,getBoundingBox().inflate(5))) p.addEffect(new MobEffectInstance(MobEffects.NAUSEA,100,0)); level.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR,getX(),getY()+1.2,getZ(),20,1,.4,1,0);}
    }
}

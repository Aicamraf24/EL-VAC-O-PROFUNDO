package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import com.vacioprofundo.registry.ModItems;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Ciempiés Colosal - HOSTILE / ground. */
public class CiempiesColosal extends VacioBase {
    public static final String ID = "ciempies_colosal";
    public CiempiesColosal(EntityType<? extends CiempiesColosal> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        
        onHitEffect=MobEffects.POISON;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(34, 5, 0.34, 24, 4, 0.2);
    }
    @Override protected boolean isFood(ItemStack stack) { return stack.is(Items.SPIDER_EYE); }
    @Override protected int abilityInterval() { return 0; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        
    }
}

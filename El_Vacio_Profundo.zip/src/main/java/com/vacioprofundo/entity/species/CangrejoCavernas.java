package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Cangrejo de las Cavernas - TERRITORIAL / ground. */
public class CangrejoCavernas extends VacioBase {
    public static final String ID = "cangrejo_cavernas";
    public CangrejoCavernas(EntityType<? extends CangrejoCavernas> type, Level level) {
        super(type, level, Behavior.TERRITORIAL, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(26, 5, 0.25, 10, 8, 0.5);
    }
    @Override protected int abilityInterval() { return 0; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        
    }
}

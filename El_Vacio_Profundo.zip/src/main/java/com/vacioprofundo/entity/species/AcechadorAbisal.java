package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Acechador Abisal - HOSTILE / ground. */
public class AcechadorAbisal extends VacioBase {
    public static final String ID = "acechador_abisal";
    public AcechadorAbisal(EntityType<? extends AcechadorAbisal> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(28, 5, 0.3, 32, 0, 0);
    }
    @Override protected int abilityInterval() { return 90; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist>7){ double a=target.getYRot()*Math.PI/180.0; double nx=target.getX()+Math.sin(a)*2.0, nz=target.getZ()-Math.cos(a)*2.0; if(randomTeleport(nx,target.getY(),nz,true)){ level.sendParticles(ParticleTypes.PORTAL,getX(),getY()+1,getZ(),12,.3,.6,.3,.1);} }
    }
}

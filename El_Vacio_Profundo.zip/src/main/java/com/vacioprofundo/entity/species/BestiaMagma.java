package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Bestia de Magma - HOSTILE / ground. */
public class BestiaMagma extends VacioBase {
    public static final String ID = "bestia_magma";
    public BestiaMagma(EntityType<? extends BestiaMagma> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.2f);
        
        fireImmune=true; igniteOnHit=true;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(76, 10, 0.27, 28, 4, 0.6);
    }
    @Override protected int abilityInterval() { return 80; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist>3&&dist<12){ ray(level,target,5f,ParticleTypes.FLAME); target.igniteForSeconds(5); }
    }
}

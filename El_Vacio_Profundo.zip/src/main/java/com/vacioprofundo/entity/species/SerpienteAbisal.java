package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Serpiente Abisal - HOSTILE / swimmer. */
public class SerpienteAbisal extends VacioBase {
    public static final String ID = "serpiente_abisal";
    public SerpienteAbisal(EntityType<? extends SerpienteAbisal> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        makeSwimmer();
        onHitEffect=MobEffects.POISON;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(40, 7, 1.0, 24, 3, 0.2);
    }
    @Override protected int abilityInterval() { return 0; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        
    }
}

package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Hidra de Cristal - TERRITORIAL / ground. */
public class HidraCristal extends VacioBase {
    public static final String ID = "hidra_cristal";
    public HidraCristal(EntityType<? extends HidraCristal> type, Level level) {
        super(type, level, Behavior.TERRITORIAL, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(110, 9, 0.25, 26, 6, 0.7);
    }
    @Override protected int abilityInterval() { return 60; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<12){ for(int i=0;i<3;i++) ray(level,target,3f,ParticleTypes.END_ROD); if(getHealth()<getMaxHealth()*.5) target.addEffect(new MobEffectInstance(MobEffects.POISON,80,0)); }
    }
}

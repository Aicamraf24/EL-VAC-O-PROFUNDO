package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Gólem de Obsidiana - TERRITORIAL / ground. */
public class GolemObsidiana extends VacioBase {
    public static final String ID = "golem_obsidiana";
    public GolemObsidiana(EntityType<? extends GolemObsidiana> type, Level level) {
        super(type, level, Behavior.TERRITORIAL, 0.0f);
        
        fireImmune=true;
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(70, 9, 0.22, 16, 6, 0.9);
    }
    @Override protected int abilityInterval() { return 110; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<4.5){ aoe(level,4.0,6f,.9); level.sendParticles(ParticleTypes.LAVA,getX(),getY()+.2,getZ(),14,1.5,.1,1.5,0);}
    }
}

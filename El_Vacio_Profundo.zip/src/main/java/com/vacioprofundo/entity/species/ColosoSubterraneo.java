package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import com.vacioprofundo.registry.ModItems;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Coloso Subterráneo - HOSTILE / ground. */
public class ColosoSubterraneo extends VacioBase {
    public static final String ID = "coloso_subterraneo";
    public ColosoSubterraneo(EntityType<? extends ColosoSubterraneo> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(140, 14, 0.2, 28, 10, 1.0);
    }
    @Override protected boolean isFood(ItemStack stack) { return stack.is(ModItems.CRISTAL_ABISAL); }
    @Override protected int abilityInterval() { return 120; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<6.5){ aoe(level,6.0,9f,1.2); level.sendParticles(ParticleTypes.POOF,getX(),getY()+.2,getZ(),25,3,.1,3,.02);}
    }
}

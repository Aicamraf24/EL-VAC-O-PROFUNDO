package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Araña Cristalina - HOSTILE / climber. */
public class AranaCristalina extends VacioBase {
    public static final String ID = "arana_cristalina";
    public AranaCristalina(EntityType<? extends AranaCristalina> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        makeClimber();
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(22, 4, 0.33, 24, 2, 0);
    }
    @Override protected int abilityInterval() { return 70; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist>3&&dist<12) ray(level,target,4f,ParticleTypes.END_ROD);
    }
}

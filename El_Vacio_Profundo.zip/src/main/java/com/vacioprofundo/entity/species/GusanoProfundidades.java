package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import com.vacioprofundo.registry.ModItems;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Gusano de las Profundidades - AMBUSH / ground. */
public class GusanoProfundidades extends VacioBase {
    public static final String ID = "gusano_profundidades";
    public GusanoProfundidades(EntityType<? extends GusanoProfundidades> type, Level level) {
        super(type, level, Behavior.AMBUSH, 0.0f);
        
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(30, 6, 0.27, 20, 2, 0.3);
    }
    @Override protected boolean isFood(ItemStack stack) { return stack.is(Items.BROWN_MUSHROOM); }
    @Override protected int abilityInterval() { return 100; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<4) aoe(level,3.0,3f,.4);
    }
}

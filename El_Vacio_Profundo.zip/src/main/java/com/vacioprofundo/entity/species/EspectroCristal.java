package com.vacioprofundo.entity.species;

import com.vacioprofundo.entity.VacioBase;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Espectro de Cristal - HOSTILE / floater. */
public class EspectroCristal extends VacioBase {
    public static final String ID = "espectro_cristal";
    public EspectroCristal(EntityType<? extends EspectroCristal> type, Level level) {
        super(type, level, Behavior.HOSTILE, 0.0f);
        makeFlyer();
        
        buildGoals();
    }
    public static AttributeSupplier.Builder attributes() {
        return baseAttributes(24, 4, 0.28, 26, 0, 0);
    }
    @Override protected int abilityInterval() { return 50; }
    @Override protected void ability(ServerLevel level, LivingEntity target, double dist) {
        if(dist<14&&dist>2) ray(level,target,4f,ParticleTypes.END_ROD);
    }
}

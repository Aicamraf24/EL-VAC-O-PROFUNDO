package com.vacioprofundo.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.EnumSet;

/**
 * Shared behaviour of every Deep Void creature. Each species is its own subclass (own stats, goals and ability).
 * Performance notes: abilities only run while a target exists and at species-defined intervals; ambush visibility
 * is evaluated every 10 ticks; swimmers stranded on land are removed; mobs despawn when far away.
 */
public abstract class VacioBase extends Monster {
    public enum Behavior { HOSTILE, NEUTRAL, TERRITORIAL, AMBUSH }

    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(VacioBase.class, EntityDataSerializers.INT);
    protected final Behavior behavior;
    protected final float fleeBelow;
    protected boolean fireImmune, lifesteal, igniteOnHit, alwaysHidden, keepHome, climber, swimmer, flyer;
    protected Holder<MobEffect> onHitEffect;
    protected BlockPos home;
    private int landTicks, specialTicks;
    // breeding
    protected int loveTicks, breedCooldown, growTicks;

    protected VacioBase(EntityType<? extends VacioBase> type, Level level, Behavior behavior, float fleeBelow) {
        super(type, level);
        this.behavior = behavior;
        this.fleeBelow = fleeBelow;
    }

    public static AttributeSupplier.Builder baseAttributes(double hp, double dmg, double spd, double follow, double armor, double kb) {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
            .add(Attributes.MOVEMENT_SPEED, spd).add(Attributes.FLYING_SPEED, spd).add(Attributes.FOLLOW_RANGE, follow)
            .add(Attributes.ARMOR, armor).add(Attributes.KNOCKBACK_RESISTANCE, kb);
    }

    // ---- movement archetypes ----
    protected void makeFlyer() {
        flyer = true;
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.navigation = new FlyingPathNavigation(this, level());
        setNoGravity(true);
    }
    protected void makeSwimmer() {
        swimmer = true;
        this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02f, 0.1f, true);
        this.lookControl = new SmoothSwimmingLookControl(this, 10);
        this.navigation = new WaterBoundPathNavigation(this, level());
    }
    protected void makeClimber() {
        climber = true;
        this.navigation = new WallClimberNavigation(this, level());
    }
    @Override public void travel(Vec3 v) {
        if (swimmer && isEffectiveAi() && isInWater()) {
            moveRelative(getSpeed(), v);
            move(MoverType.SELF, getDeltaMovement());
            setDeltaMovement(getDeltaMovement().scale(0.9));
            if (getTarget() == null) setDeltaMovement(getDeltaMovement().add(0, -0.005, 0));
        } else super.travel(v);
    }
    @Override public boolean isPushedByFluid() { return !swimmer; }
    @Override public boolean canBreatheUnderwater() { return swimmer || super.canBreatheUnderwater(); }
    @Override public boolean onClimbable() { return climber ? this.horizontalCollision : super.onClimbable(); }
    @Override public boolean fireImmune() { return fireImmune || super.fireImmune(); }
    @Override public boolean removeWhenFarAway(double distSq) { return behavior != Behavior.NEUTRAL || distSq > 96 * 96; }
    @Override public int getMaxSpawnClusterSize() { return 2; }

    // ---- AI ----
    /** Goals are built from the subclass constructor (fields are not ready when Mob calls registerGoals). */
    @Override protected void registerGoals() { }
    protected final void buildGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        if (fleeBelow > 0) goalSelector.addGoal(1, new FleeWhenWeakGoal(this));
        goalSelector.addGoal(2, new AbilityGoal(this));
        goalSelector.addGoal(2, new MateGoal(this));
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15, true));
        if (behavior == Behavior.TERRITORIAL || keepHome) goalSelector.addGoal(5, new ReturnHomeGoal(this));
        if (flyer) goalSelector.addGoal(6, new WaterAvoidingRandomFlyingGoal(this, 0.9));
        else if (swimmer) goalSelector.addGoal(6, new RandomSwimmingGoal(this, 1.0, 40));
        else goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 10f));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        switch (behavior) {
            case HOSTILE, AMBUSH -> targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
            case TERRITORIAL -> targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                (e, l) -> home == null || e.distanceToSqr(home.getX(), home.getY(), home.getZ()) < 14 * 14));
            default -> { }
        }
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder b) { super.defineSynchedData(b); b.define(DATA_STATE, 0); }
    public boolean isResting() { return (entityData.get(DATA_STATE) & 1) != 0; }
    public float specialAmount() { return (entityData.get(DATA_STATE) & 2) != 0 ? 1f : 0f; }
    public int phase() { return (entityData.get(DATA_STATE) >> 2) & 3; }
    protected void setStateBits(boolean resting, boolean special, int phase) {
        int v = (resting ? 1 : 0) | (special ? 2 : 0) | ((phase & 3) << 2) | (isBaby() ? 16 : 0);
        if (v != entityData.get(DATA_STATE)) entityData.set(DATA_STATE, v);
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide()) return;
        if (home == null) home = blockPosition();
        if (specialTicks > 0) specialTicks--;
        if (loveTicks > 0) { loveTicks--; if (tickCount % 20 == 0 && level() instanceof ServerLevel sl0) sl0.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight() + 0.2, getZ(), 2, 0.3, 0.2, 0.3, 0.0); }
        if (breedCooldown > 0) breedCooldown--;
        if (isBaby() && --growTicks <= 0) setBaby(false);
        if (tickCount % 10 == 0) {
            boolean hidden = false;
            if (alwaysHidden || behavior == Behavior.AMBUSH) {
                Player near = level().getNearestPlayer(this, alwaysHidden ? 4.5 : 6.0);
                hidden = near == null && getTarget() == null && hurtTime == 0;
                setInvisible(hidden);
            }
            setStateBits(hidden || (getTarget() == null && !isAggressive()), specialTicks > 0, phase());
        }
        if (swimmer && !isInWater()) { if (++landTicks > 100) discard(); } else landTicks = 0;
    }

    @Override public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean ok = super.doHurtTarget(level, target);
        if (ok && target instanceof LivingEntity le) {
            if (onHitEffect != null) le.addEffect(new MobEffectInstance(onHitEffect, 100, 0));
            if (lifesteal) heal(2.0f);
            if (igniteOnHit) le.igniteForSeconds(4);
        }
        return ok;
    }

    // ---- natural spawning: only on the cavern floor (never on ceiling spikes, bridges or floating islands) ----
    /** Highest Y at which ground creatures may spawn naturally (cavern floor lies around Y 13 +/- 17). */
    private static final int FLOOR_MAX_Y = 32, FLYER_MAX_Y = 48, SWIM_MAX_Y = 20;

    @Override
    public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason reason) {
        if (reason == EntitySpawnReason.NATURAL || reason == EntitySpawnReason.CHUNK_GENERATION) {
            if (swimmer) {
                if (level.getFluidState(blockPosition()).isEmpty() || getY() > SWIM_MAX_Y) return false;   // water only
            } else if (flyer) {
                if (getY() > FLYER_MAX_Y) return false;
            } else {
                if (getY() > FLOOR_MAX_Y) return false;
                BlockPos below = blockPosition().below();
                if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP) || !level.getFluidState(blockPosition()).isEmpty()) return false;
                if (!level.getBlockState(blockPosition()).isAir() || !level.getBlockState(blockPosition().above()).isAir()) return false;
            }
        }
        return super.checkSpawnRules(level, reason);
    }

    // ---- breeding (every species except the final boss: it has no food item) ----
    /** Item that puts two adults of this species in love mode. Default: none (cannot breed). */
    protected boolean isFood(ItemStack stack) { return false; }

    @Override public boolean isBaby() { return (entityData.get(DATA_STATE) & 16) != 0; }
    public void setBaby(boolean baby) {
        growTicks = baby ? 24000 : 0;                      // 20 minutes to grow up
        AttributeInstance sc = getAttribute(Attributes.SCALE);
        if (sc != null) sc.setBaseValue(baby ? 0.5 : 1.0);
        int v = entityData.get(DATA_STATE);
        entityData.set(DATA_STATE, baby ? (v | 16) : (v & ~16));
    }

    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (isFood(stack)) {
            if (level().isClientSide()) return InteractionResult.SUCCESS;
            if (!isBaby() && loveTicks == 0 && breedCooldown <= 0) {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                loveTicks = 600;
                if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight(), getZ(), 6, 0.4, 0.3, 0.4, 0.0);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }
        return super.mobInteract(player, hand);
    }

    /** Hostile creatures ignore players while in love mode and babies are passive (unless hurt by that player). */
    @Override public void setTarget(LivingEntity target) {
        if (target instanceof Player && (loveTicks > 0 || isBaby()) && getLastHurtByMob() != target) return;
        super.setTarget(target);
    }

    /** Babies drop nothing. */
    @Override protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
        if (isBaby()) return;
        super.dropAllDeathLoot(level, source);
    }

    // ---- species abilities ----
    protected int abilityInterval() { return 0; }
    protected void ability(ServerLevel level, LivingEntity target, double dist) { }
    final void runAbility(ServerLevel level, LivingEntity target) {
        specialTicks = 12;
        ability(level, target, distanceTo(target));
    }

    // ---- helpers for abilities ----
    protected void ray(ServerLevel level, LivingEntity target, float dmg, ParticleOptions particle) {
        if (!hasLineOfSight(target)) return;
        Vec3 a = getEyePosition(), b = target.getBoundingBox().getCenter();
        int steps = Math.min(16, (int) (a.distanceTo(b) * 1.2) + 1);
        for (int i = 1; i <= steps; i++) {
            Vec3 p = a.lerp(b, i / (double) steps);
            level.sendParticles(particle, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        target.hurtServer(level, level.damageSources().mobAttack(this), dmg);
    }
    protected void aoe(ServerLevel level, double radius, float dmg, double knock) {
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius), t -> t != this && !(t instanceof VacioBase) && t.isAlive())) {
            e.hurtServer(level, level.damageSources().mobAttack(this), dmg);
            Vec3 d = e.position().subtract(position()).normalize();
            e.push(d.x * knock, 0.35 + knock * 0.2, d.z * knock);
            e.hurtMarked = true;
        }
    }

    // ---- goals ----
    static final class AbilityGoal extends Goal {
        private final VacioBase mob; private int cd;
        AbilityGoal(VacioBase mob) { this.mob = mob; setFlags(EnumSet.noneOf(Flag.class)); }
        @Override public boolean canUse() { return mob.abilityInterval() > 0 && !mob.isBaby() && mob.getTarget() != null && mob.getTarget().isAlive(); }
        @Override public boolean requiresUpdateEveryTick() { return false; }
        @Override public void start() { cd = mob.abilityInterval() / 2; }
        @Override public void tick() {
            if (--cd <= 0 && mob.level() instanceof ServerLevel sl && mob.getTarget() != null) { cd = mob.abilityInterval(); mob.runAbility(sl, mob.getTarget()); }
        }
    }
    static final class MateGoal extends Goal {
        private final VacioBase mob; private VacioBase partner;
        MateGoal(VacioBase mob) { this.mob = mob; setFlags(EnumSet.of(Flag.MOVE)); }
        private VacioBase find() {
            VacioBase best = null; double bd = 1e9;
            for (VacioBase e : mob.level().getEntitiesOfClass(VacioBase.class, mob.getBoundingBox().inflate(12), x -> x != mob && x.getType() == mob.getType() && x.loveTicks > 0 && !x.isBaby())) {
                double d = mob.distanceToSqr(e); if (d < bd) { bd = d; best = e; }
            }
            return best;
        }
        @Override public boolean canUse() {
            if (mob.loveTicks <= 0 || mob.isBaby()) return false;
            partner = find(); return partner != null;
        }
        @Override public boolean canContinueToUse() { return mob.loveTicks > 0 && partner != null && partner.isAlive() && partner.loveTicks > 0; }
        @Override public void tick() {
            mob.getLookControl().setLookAt(partner, 10f, mob.getMaxHeadXRot());
            if (mob.distanceToSqr(partner) > 6.25) { if (mob.tickCount % 10 == 0) mob.getNavigation().moveTo(partner, 1.0); return; }
            if (!(mob.level() instanceof ServerLevel sl)) return;
            // population cap keeps the dimension light on weaker PCs
            if (sl.getEntitiesOfClass(VacioBase.class, mob.getBoundingBox().inflate(48), x -> x.getType() == mob.getType()).size() < 12) {
                Entity e = mob.getType().create(sl, EntitySpawnReason.BREEDING);
                if (e instanceof VacioBase kid) {
                    kid.setBaby(true); kid.setPos(mob.getX(), mob.getY(), mob.getZ()); sl.addFreshEntity(kid);
                    sl.sendParticles(ParticleTypes.HEART, mob.getX(), mob.getY() + 1, mob.getZ(), 8, 0.5, 0.4, 0.5, 0.0);
                }
            }
            mob.loveTicks = 0; partner.loveTicks = 0; mob.breedCooldown = 6000; partner.breedCooldown = 6000;
        }
    }
    /** Territorial mobs walk back to their spawn point when they have no target and wander too far. */
    static final class ReturnHomeGoal extends Goal {
        private final VacioBase mob;
        ReturnHomeGoal(VacioBase mob) { this.mob = mob; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return mob.home != null && mob.getTarget() == null && mob.blockPosition().distSqr(mob.home) > 18 * 18; }
        @Override public void start() { mob.getNavigation().moveTo(mob.home.getX() + 0.5, mob.home.getY(), mob.home.getZ() + 0.5, 0.9); }
        @Override public boolean canContinueToUse() { return !mob.getNavigation().isDone() && mob.getTarget() == null; }
    }
    static final class FleeWhenWeakGoal extends Goal {
        private final VacioBase mob; private Vec3 dest;
        FleeWhenWeakGoal(VacioBase mob) { this.mob = mob; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() {
            LivingEntity t = mob.getTarget();
            if (t == null || mob.getHealth() > mob.getMaxHealth() * mob.fleeBelow) return false;
            dest = DefaultRandomPos.getPosAway(mob, 16, 7, t.position());
            return dest != null;
        }
        @Override public void start() { mob.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.4); }
        @Override public boolean canContinueToUse() { return !mob.getNavigation().isDone(); }
    }
}

# El Vacío Profundo — mod para Minecraft Java 26.1.2 (Fabric)

Dimensión subterránea con 8 biomas, 20 criaturas (con jefe), 8 minerales, 5 conjuntos de armadura, 6 armas/herramientas,
ciudades antiguas y 15 estructuras más, portal propio y 4 logros. ID del mod: `vacio_profundo` (todos los ids viven en ese espacio de nombres).

## ESTADO REAL DEL PROYECTO (léelo primero)
| Nivel | Estado |
|---|---|
| Validación estática (JSON, rutas de texturas/modelos, referencias cruzadas de registros, biomas, features, loot, recetas, idiomas, balance de llaves en Java) | **HECHA** con un script (ver `Checklist` abajo) |
| Compilación (`gradle build`) | **NO REALIZADA**. El entorno donde se generó no tiene red ni Gradle/Minecraft |
| Prueba dentro del juego | **NO REALIZADA** |

El código Java se escribió con nombres Mojang sin ofuscar de 26.1, **sin poder verificar firmas contra el juego**. Es muy probable que
la primera compilación muestre algunos errores de API. Pega el log (GitHub Actions o `gradle build`) y se corrigen por tandas.
Zonas con mayor riesgo de firma cambiada: `VacioBase` (goals/atributos, `doHurtTarget`, `hurtServer`), `RevAbismo` (`ServerBossEvent`, `EntitySpawnReason`),
`PortalHandler` (`TeleportTransition`), `ProcPiece`/`VacioStructure` (API de estructuras, getters NBT `getStringOr`), `ModMaterials` (ArmorMaterial/ToolMaterial),
`VacioModel/VacioRenderer` (estados de render) y `ModItems` (creative tab).
Los JSON de datos (dimension_type, biomas, noise_settings) usan el formato clásico; si 26.1 movió campos (p. ej. a "attributes"), el juego lo indicará en el log al crear el mundo.

## Versiones (de docs.fabricmc.net para 26.1.2)
Java 25 · Gradle 9.x · Fabric Loom 1.15.5 (`net.fabricmc.fabric-loom`, sin mapeos) · Fabric Loader ≥ 0.19.1 · Fabric API `0.145.4+26.1.2`.
Si Loom pide otra versión de Gradle, cámbiala en `gradle/wrapper/gradle-wrapper.properties` y en `.github/workflows/build.yml`.

## Cómo compilar
**Opción A – GitHub Actions (recomendada)**: sube el contenido del ZIP a un repositorio de GitHub. El workflow `build` compila y publica el `.jar`
en *Actions → build → Artifacts*. (El `gradle-wrapper.jar` no se incluye porque el entorno no tenía red; el workflow instala Gradle directamente.)
**Opción B – local**: JDK 25 y Gradle 9.x instalados → `gradle wrapper` (opcional) y `gradle build`. El jar queda en `build/libs/`.
Instala en `mods/` junto a Fabric API (el `-sources.jar` no se usa).

## Contenido
- **Dimensión** `vacio_profundo:vacio_profundo`: techo cavernoso, abismos, puentes naturales (ribbons de densidad), islas flotantes, lagos/mares, valles que se llenan de agua, estalactitas/estalagmitas, manantiales de agua y lava, lagunas de lava.
- **Biomas** (8): Abismo Cristalino, Bosque Bioluminiscente, Pantano Abisal, Cavernas de Magma, Mar Subterráneo, Jardines de Hongos, Tierras de Cristal Oscuro, Abismo Eterno (profundo, poca luz, monstruos fuertes). Cada uno con suelo, flora, minerales, spawns y colores propios.
- **Portal**: 2 *Marco del Vacío* + 2 amatistas + 2 obsidiana → `OA/AO` (2 marcos); *Núcleo del Vacío* (ojo de Ender + 4 amatistas + 4 obsidiana). Construye un rectángulo de marcos (interior mínimo 2×3) y usa el Núcleo sobre un marco. Quédate ~2 s dentro. Ida y vuelta conservan inventario y progreso; si no hay portal en destino se construye uno.
- **Minerales** (8, con bloque, item, generación y receta): Cristal Abisal, Mineral de Vacío, Esencia Oscura, Piedra Astral, Cuarzo Profundo, Mineral de Sangre, Fragmento Dimensional, Obsidiana Viviente. + bloques de almacenamiento.
- **Equipo**: 5 armaduras (Cristal Abisal, Piedra Astral, Obsidiana Viviente, Cazador de las Profundidades, Vacío; cada una con textura de capa y bonus de set), Espada Abisal, Hacha de Obsidiana Viviente, Pico de Cristal, Arco Dimensional (flechas sin gravedad), Daga de las Sombras (+4 de daño por la espalda), Bastón del Vacío (rayo perforante de 20 bloques).
- **Progresión**: Cristal (hierro+) → Piedra Astral (diamante+) → Obsidiana Viviente (netherita) → Vacío (requiere Escama del Rey, drop del jefe). El Bastón requiere el Corazón del Abismo (jefe).
- **Criaturas** (20, clases Java individuales, esqueleto/anatomía/textura propios): Acechador Abisal, Araña Cristalina, Gusano de las Profundidades, Murciélago Gigante, Gólem de Obsidiana, Ciempiés Colosal, Sanguijuela Abisal, Devorador de Hongos, Espectro de Cristal, Cangrejo de las Cavernas, Reptador de las Sombras, Coloso Subterráneo, Serpiente Abisal, Devorador de Almas, Guardián de las Ruinas, Bestia de Magma, Cazador Invisible, Hidra de Cristal, Leviatán Subterráneo, **Rey del Abismo**.
  Comportamientos: hostil / neutral / territorial / emboscada (invisible hasta acercarte), voladores, nadadores, trepador de paredes, huida con poca vida (Bestia de Magma), ataques especiales (teletransporte, rayos, ondas de choque, succión, veneno…).
  Animaciones: caminar/correr (escala con velocidad y agresividad), atacar, daño y muerte (renderer vanilla), descansar (cabeza baja/respiración), habilidad especial (brazos arriba/mandíbula), aleteo, ondulación de segmentos, fragmentos orbitando.
  Invocación: no hay huevos de aparición; usa `/summon vacio_profundo:acechador_abisal` (etc.).
- **Jefe**: Rey del Abismo (450 PV, barra de jefe, 3 fases, rayos, onda de choque, invocaciones limitadas a 6 súbditos, succión + drenaje de vida y furia en la fase 3). Duerme en el **Santuario del Vacío** (arena circular, 8 pilares, 4 cofres, guardianes) y no ataca hasta que un jugador se acerca a 40 bloques. Drops: Corazón del Abismo, Fragmentos de Corona, Escamas del Rey, Lingotes de Vacío, Fragmentos Dimensionales, Obsidiana Viviente, tablillas.
- **Estructuras**: Ciudad Antigua (torres, salones, bibliotecas, laboratorios, templos, cárcel, estatua, cámara del tesoro, altares, caminos, puentes entre torres y muralla en ruinas), Ciudad Colgante (la misma sobre una isla flotante), Santuario del Vacío, Templo Perdido, Biblioteca Abandonada, Laboratorio Antiguo, Mina Abandonada, Estatua Gigante, Cámara del Tesoro (puerta secreta), Cárcel Antigua, Altar Misterioso, Campamento, Torre de Vigilancia, Ruinas, Puesto de Exploración, Cueva con Tesoro. Los cofres contienen 12 *Tablillas Antiguas* con fragmentos de la historia de la dimensión.
- **Idiomas**: es_es, es_mx, en_us. **Sin audio**: no hay `.ogg` ni referencias a sonidos propios (se usan sonidos vanilla de bloques/armaduras).

## Compatibilidad con tus otros mods
Espacio de nombres único `vacio_profundo`; no toca ni reemplaza contenido de Acechador, Cápsulas, Gancho, Reptilia ni End Realms; sin dependencias obligatorias de ellos
(solo Fabric API). Las etiquetas que extiende (`minecraft:mineable/*`, `needs_*_tool`, `incorrect_for_diamond_tool`) usan `"replace": false`, así que se suman en vez de sobrescribir.
Integraciones opcionales (p. ej. drops o spawns compartidos) no están implementadas: requieren conocer los ids de tus mods.

## Optimización
Habilidades solo con objetivo y por intervalos (50-120 ticks); visibilidad de emboscada cada 10 ticks; nadadores varados se eliminan; spawns de bajo peso y grupos máx. 2;
mobs lejanos desaparecen; partículas de bioma con probabilidad ≤ 0.004; estructuras generan solo dentro de la caja del chunk con funciones hash (sin estado).

## Limitaciones conocidas (honestas)
- "Ríos luminosos" y "cascadas": se aproximan con valles que se llenan de agua teñida por bioma, manantiales y flora luminosa; no hay agua que emita luz.
- Las texturas son PNG generados proceduralmente (original, estilo Minecraft); los modelos de criaturas son esqueletos de cubos distintos por especie, no mallas artísticas.
- Los "modelos de estructuras" son constructores procedurales en Java (no archivos NBT), por eso no hay `.nbt`.
- El Gusano "bajo tierra" se implementa como emboscada invisible, no como excavación real.
- Hitboxes y balance numérico sin playtest.

## Checklist (validación estática ejecutada)
512 JSON válidos · todas las texturas/modelos/blockstates/items referenciados existen · 43 bloques, 50 items y 20 entidades registrados con loot, modelo e idioma ·
biomas → placed features → configured features resueltos · spawners apuntan a entidades existentes · 16 estructuras con su structure_set · idiomas es/en con las mismas claves · referencias `ModBlocks/ModItems/ModEntities.X` existentes · llaves/paréntesis balanceados.
